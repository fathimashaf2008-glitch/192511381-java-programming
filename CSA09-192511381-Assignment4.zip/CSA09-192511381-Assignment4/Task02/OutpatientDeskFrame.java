import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class OutpatientDeskFrame extends JFrame {
    private final JTextField patientIdField = new JTextField(15);
    private final JComboBox<String> deptCombo = new JComboBox<>();
    private final JComboBox<String> doctorCombo = new JComboBox<>();
    private final JComboBox<String> slotCombo = new JComboBox<>(new String[]{
            "09:00 AM - 09:30 AM", "10:00 AM - 10:30 AM", "11:30 AM - 12:00 PM", "02:30 PM - 03:00 PM", "04:00 PM - 04:30 PM"
    });
    private final JButton bookBtn = new JButton("Book Appointment");
    private final JButton resetBtn = new JButton("Reset");
    private final JLabel statusLabel = new JLabel("Enter patient details to book an appointment.");

    private final Map<String, List<String>> deptDoctors = new HashMap<>();
    private final Set<String> bookedSlots = new HashSet<>();

    public OutpatientDeskFrame() {
        super("Hospital Outpatient Appointment Desk");
        initData();

        setLayout(new BorderLayout(10, 10));
        JPanel formPanel = new JPanel(new GridLayout(4, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 5, 15));

        formPanel.add(new JLabel("Patient ID:"));
        formPanel.add(patientIdField);
        formPanel.add(new JLabel("Department:"));
        formPanel.add(deptCombo);
        formPanel.add(new JLabel("Doctor:"));
        formPanel.add(doctorCombo);
        formPanel.add(new JLabel("Time Slot:"));
        formPanel.add(slotCombo);

        JPanel btnPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 8));
        btnPanel.add(bookBtn);
        btnPanel.add(resetBtn);

        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.setBorder(BorderFactory.createEmptyBorder(0, 15, 10, 15));
        southPanel.add(btnPanel, BorderLayout.NORTH);
        southPanel.add(statusLabel, BorderLayout.SOUTH);

        add(formPanel, BorderLayout.CENTER);
        add(southPanel, BorderLayout.SOUTH);

        deptCombo.addItemListener(e -> {
            if (e.getStateChange() == java.awt.event.ItemEvent.SELECTED) {
                refreshDoctors();
            }
        });
        bookBtn.addActionListener(e -> bookAppointment());
        resetBtn.addActionListener(e -> resetForm());

        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (!patientIdField.getText().trim().isEmpty()) {
                    int choice = JOptionPane.showConfirmDialog(
                            OutpatientDeskFrame.this,
                            "A booking is currently in progress. Discard and exit?",
                            "Confirm Exit",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.WARNING_MESSAGE);
                    if (choice == JOptionPane.YES_OPTION) {
                        dispose();
                    }
                } else {
                    dispose();
                }
            }
        });

        refreshDoctors();
        pack();
        setLocationRelativeTo(null);
    }

    private void initData() {
        deptDoctors.put("Cardiology", Arrays.asList("Dr. Meera Nair", "Dr. Arjun Rao"));
        deptDoctors.put("Neurology", Arrays.asList("Dr. Siddharth Menon", "Dr. Kavitha Iyer"));
        deptDoctors.put("Orthopedics", Arrays.asList("Dr. Rajesh Kumar", "Dr. Priya Sundar"));
        deptDoctors.put("General Medicine", Arrays.asList("Dr. Ananya Das", "Dr. Vikram Sen"));

        for (String dept : deptDoctors.keySet()) {
            deptCombo.addItem(dept);
        }
    }

    private void refreshDoctors() {
        String selectedDept = (String) deptCombo.getSelectedItem();
        doctorCombo.removeAllItems();
        if (selectedDept != null && deptDoctors.containsKey(selectedDept)) {
            for (String doc : deptDoctors.get(selectedDept)) {
                doctorCombo.addItem(doc);
            }
        }
    }

    private void bookAppointment() {
        String patientId = patientIdField.getText().trim();
        String dept = (String) deptCombo.getSelectedItem();
        String doctor = (String) doctorCombo.getSelectedItem();
        String slot = (String) slotCombo.getSelectedItem();

        if (patientId.isEmpty()) {
            statusLabel.setText("Error: Patient ID is required.");
            JOptionPane.showMessageDialog(this, "Please enter a valid Patient ID.", "Validation Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String bookingKey = doctor + "|" + slot;
        if (bookedSlots.contains(bookingKey)) {
            statusLabel.setText("Error: Selected slot is already booked for " + doctor);
            JOptionPane.showMessageDialog(this, "Time slot already booked for " + doctor + ".", "Slot Unavailable", JOptionPane.WARNING_MESSAGE);
            return;
        }

        bookedSlots.add(bookingKey);
        String msg = "Booked: Patient " + patientId + " | " + dept + " | " + doctor + " (" + slot + ")";
        statusLabel.setText(msg);
        JOptionPane.showMessageDialog(this, msg, "Appointment Confirmed", JOptionPane.INFORMATION_MESSAGE);
        patientIdField.setText("");
    }

    private void resetForm() {
        patientIdField.setText("");
        deptCombo.setSelectedIndex(0);
        slotCombo.setSelectedIndex(0);
        statusLabel.setText("Form reset.");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new OutpatientDeskFrame().setVisible(true));
    }
}
