# CSA09 - Programming in Java: Assignment 4 (CO4)
## Event-Driven GUI Design

* **Student Name:** Fathima Shafreena. F
* **Register Number:** 192511381
* **Course:** Programming in Java (CSA09)
* **Java Version:** JDK 17 / JDK 21 (Compatible with Java 8+)
* **Repository:** `CSA09-192511381-Assignment4`

---

## Folder Structure
- `Task01/`: Refactored `FeeWindow` (Swing) separating UI from `FeeService` business logic and background database operations via `SwingWorker`.
- `Task02/`: `OutpatientDeskFrame` modeling hospital appointment scheduling with dynamic department-doctor mapping, validation, and window-closing confirmation.
- `Task03/`: `LibrarySearchFrame` demonstrating nested `BorderLayout` and `FlowLayout` containers for responsive resizing.
- `Task04/`: `DrawPad` (AWT) with fixed `mouseClicked` handler and persistent point rendering inside `paint(Graphics)`.
- `Task05/`: Currency `Converter` in four event-handling styles (Self-listener, Named Inner Class, Anonymous Inner Class, and Lambda Expression).
- `Task06/`: `EventRegistrationApp` layered Swing + JDBC desktop application with MySQL `schema.sql`, input validation, duplicate prevention, paginated/filtered table view, and CSV export.

---

## Compilation & Execution Instructions

### Tasks 01 to 05 (Standard JDK)
Navigate to the respective task directory, compile, and run:
```bash
cd Task01
javac *.java
java FeeWindow

cd ../Task02
javac *.java
java OutpatientDeskFrame

cd ../Task03
javac *.java
java LibrarySearchFrame

cd ../Task04
javac *.java
java DrawPad

cd ../Task05
javac *.java
java Converter
```

### Task 06 (Requires MySQL & MySQL Connector/J)
1. Execute `Task06/schema.sql` in your MySQL server to create the `campus_events` database and `registrations` table.
2. Update database credentials (`DB_URL`, `DB_USER`, `DB_PWD`) in `Task06/RegistrationDAO.java` if needed.
3. Compile and run with the MySQL JDBC driver on the classpath:
```bash
cd Task06
javac -cp .:mysql-connector-j-8.3.0.jar *.java
java -cp .:mysql-connector-j-8.3.0.jar EventRegistrationApp
```
*(On Windows, replace `:` with `;` in the classpath).*

---

## Task Results Summary
- **Task 01:** Eliminated EDT blocking, SQL injection, and tight coupling by decoupling `FeeWindow` from `FeeService` using `PreparedStatement` and `SwingWorker`.
- **Task 02:** Implemented cascading `JComboBox` selection (`Department` -> `Doctor`), form validation, and `WindowAdapter` exit confirmation.
- **Task 03:** Verified responsive layout where `CENTER` `JScrollPane` expands dynamically while `NORTH` search bar and `SOUTH` navigation controls retain preferred height.
- **Task 04:** Fixed `mouseclicked` typo (`@Override` enforced) and stored `Point` objects in an `ArrayList` so dots persist across window minimize/restore cycles.
- **Task 05:** Implemented and verified all four listener paradigms plus Enter-key trigger and `JOptionPane` dialog output.
- **Task 06:** Built a 3-tier Swing-JDBC application supporting valid registrations, input validation errors, duplicate registration blocking (`UNIQUE(reg_no, event_name)`), event filtering, and CSV export.
