import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class LibrarySearchFrame extends JFrame {
    private final JTextField searchField = new JTextField(22);
    private final JComboBox<String> categoryCombo = new JComboBox<>(new String[]{"All Categories", "Computer Science", "Electronics", "Mathematics", "Literature"});
    private final JButton searchBtn = new JButton("Search");
    private final JButton prevBtn = new JButton("Prev");
    private final JButton nextBtn = new JButton("Next");
    private final JButton reserveBtn = new JButton("Reserve");
    private final JLabel statusLabel = new JLabel("Showing 5 available books.");
    private final JTable resultsTable;

    public LibrarySearchFrame() {
        super("Campus Library Search Screen");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(8, 8));

        // NORTH: Title + Search Row
        JPanel northContainer = new JPanel(new BorderLayout());
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        titlePanel.setBackground(new Color(26, 54, 93));
        JLabel titleLabel = new JLabel("SIMATS CENTRAL LIBRARY CATALOG");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        titlePanel.add(titleLabel);

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        searchPanel.add(new JLabel("Keyword:"));
        searchPanel.add(searchField);
        searchPanel.add(new JLabel("Category:"));
        searchPanel.add(categoryCombo);
        searchPanel.add(searchBtn);

        northContainer.add(titlePanel, BorderLayout.NORTH);
        northContainer.add(searchPanel, BorderLayout.SOUTH);

        // CENTER: Expanding Results Table
        String[] columns = {"Book ID", "Title", "Author", "Category", "Status"};
        Object[][] data = {
                {"CS101", "Effective Java (3rd Ed.)", "Joshua Bloch", "Computer Science", "Available"},
                {"CS102", "Clean Code", "Robert C. Martin", "Computer Science", "Available"},
                {"CS103", "Introduction to Algorithms", "Thomas H. Cormen", "Computer Science", "Checked Out"},
                {"MA201", "Discrete Mathematics", "Kenneth H. Rosen", "Mathematics", "Available"},
                {"EC301", "Digital Design", "M. Morris Mano", "Electronics", "Available"}
        };
        resultsTable = new JTable(new DefaultTableModel(data, columns));
        JScrollPane centerScroll = new JScrollPane(resultsTable);
        centerScroll.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));

        // SOUTH: Navigation Buttons + Status Bar
        JPanel southContainer = new JPanel(new BorderLayout());
        JPanel navPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 6));
        navPanel.add(prevBtn);
        navPanel.add(nextBtn);
        navPanel.add(reserveBtn);

        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 4));
        statusPanel.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY));
        statusPanel.add(statusLabel);

        southContainer.add(navPanel, BorderLayout.NORTH);
        southContainer.add(statusPanel, BorderLayout.SOUTH);

        add(northContainer, BorderLayout.NORTH);
        add(centerScroll, BorderLayout.CENTER);
        add(southContainer, BorderLayout.SOUTH);

        searchBtn.addActionListener(e -> statusLabel.setText("Filtered results for: '" + searchField.getText().trim() + "' in " + categoryCombo.getSelectedItem()));
        prevBtn.addActionListener(e -> statusLabel.setText("Loaded previous page of results."));
        nextBtn.addActionListener(e -> statusLabel.setText("Loaded next page of results."));
        reserveBtn.addActionListener(e -> {
            int row = resultsTable.getSelectedRow();
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Please select a book row first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            } else {
                String bookTitle = resultsTable.getValueAt(row, 1).toString();
                statusLabel.setText("Reserved book: " + bookTitle);
                JOptionPane.showMessageDialog(this, "Book reserved: " + bookTitle, "Reservation Confirmed", JOptionPane.INFORMATION_MESSAGE);
            }
        });

        setSize(720, 440);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new LibrarySearchFrame().setVisible(true));
    }
}
