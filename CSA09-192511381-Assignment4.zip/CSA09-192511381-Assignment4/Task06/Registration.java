public class Registration {
    private final int id;
    private final String regNo;
    private final String studentName;
    private final String department;
    private final String eventName;
    private final String registeredAt;

    public Registration(int id, String regNo, String studentName, String department, String eventName, String registeredAt) {
        this.id = id;
        this.regNo = regNo;
        this.studentName = studentName;
        this.department = department;
        this.eventName = eventName;
        this.registeredAt = registeredAt;
    }

    public int getId() { return id; }
    public String getRegNo() { return regNo; }
    public String getStudentName() { return studentName; }
    public String getDepartment() { return department; }
    public String getEventName() { return eventName; }
    public String getRegisteredAt() { return registeredAt; }
}
