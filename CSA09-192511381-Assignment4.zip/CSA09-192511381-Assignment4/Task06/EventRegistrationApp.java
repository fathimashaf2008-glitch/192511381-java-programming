import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.table.DefaultTableModel;

public class EventRegistrationApp extends JFrame {
    private final JTextField regNoField = new JTextField(12);
    private final JTextField nameField = new JTextField(15);
    private final JTextField deptField = new JTextField(12);
    private final JComboBox<String> eventCombo = new JComboBox<>(new String[]{
            "Hackathon 2026", "AI Symposium", "Cultural Fest - Music", "Robotics Challenge"
    });
    private final JComboBox<String> filterCombo = new JComboBox<>(new String[]{
            "All Events", "Hackathon 2026", "AI Symposium", "Cultural Fest - Music", "Robotics Challenge"
    });

    private final DefaultTableModel tableModel = new DefaultTableModel(
            new String[]{"ID", "Register No", "Student Name", "Department", "Event", "Timestamp"}, 0);
    private final JTable regTable = new JTable(tableModel);
    private final JLabel statusLabel = new JLabel("Ready");
    private final RegistrationService service = new RegistrationService();
    private List<Registration> currentRows = new ArrayList<>();
    private int currentPage = 1;
    private static final int PAGE_SIZE = 50;

    public EventRegistrationApp() {
        super("Campus Event Registration System - Fathima Shafreena. F (192511381)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exportItem = new JMenuItem("Export CSV...");
        JMenuItem exitItem = new JMenuItem("Exit");
        exportItem.addActionListener(e -> exportCsv());
        exitItem.addActionListener(e -> dispose());
        fileMenu.add(exportItem);
        fileMenu.addSeparator();
        fileMenu.add(exitItem);

        JMenu viewMenu = new JMenu("View");
        JMenuItem refreshItem = new JMenuItem("Refresh Table");
        refreshItem.addActionListener(e -> loadRegistrationsAsync());
        viewMenu.add(refreshItem);

        menuBar.add(fileMenu);
        menuBar.add(viewMenu);
        setJMenuBar(menuBar);

        // Top Registration Form
        JPanel formPanel = new JPanel(new GridLayout(2, 5, 8, 6));
        formPanel.setBorder(BorderFactory.createTitledBorder("New Student Event Registration"));
        formPanel.add(new JLabel("Register No:"));
        formPanel.add(new JLabel("Student Name:"));
        formPanel.add(new JLabel("Department:"));
        formPanel.add(new JLabel("Event:"));
        formPanel.add(new JLabel("Action:"));

        JButton registerBtn = new JButton("Register");
        formPanel.add(regNoField);
        formPanel.add(nameField);
        formPanel.add(deptField);
        formPanel.add(eventCombo);
        formPanel.add(registerBtn);

        // Filter & Pagination Bar + Table
        JPanel centerPanel = new JPanel(new BorderLayout(6, 6));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));

        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 4));
        JButton prevPageBtn = new JButton("< Prev");
        JButton nextPageBtn = new JButton("Next >");
        JButton exportBtn = new JButton("Export Filtered CSV");
        filterPanel.add(new JLabel("Filter by Event:"));
        filterPanel.add(filterCombo);
        filterPanel.add(prevPageBtn);
        filterPanel.add(nextPageBtn);
        filterPanel.add(exportBtn);

        centerPanel.add(filterPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(regTable), BorderLayout.CENTER);

        // Status Bar
        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.setBorder(BorderFactory.createEmptyBorder(0, 10, 6, 10));
        statusPanel.add(statusLabel);

        add(formPanel, BorderLayout.NORTH);
        add(centerPanel, BorderLayout.CENTER);
        add(statusPanel, BorderLayout.SOUTH);

        registerBtn.addActionListener(e -> handleRegister());
        filterCombo.addActionListener(e -> {
            currentPage = 1;
            loadRegistrationsAsync();
        });
        prevPageBtn.addActionListener(e -> {
            if (currentPage > 1) {
                currentPage--;
                loadRegistrationsAsync();
            }
        });
        nextPageBtn.addActionListener(e -> {
            currentPage++;
            loadRegistrationsAsync();
        });
        exportBtn.addActionListener(e -> exportCsv());

        setSize(860, 520);
        setLocationRelativeTo(null);
        loadRegistrationsAsync();
    }

    private void handleRegister() {
        String regNo = regNoField.getText();
        String name = nameField.getText();
        String dept = deptField.getText();
        String event = (String) eventCombo.getSelectedItem();

        statusLabel.setText("Validating and saving registration...");
        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                service.registerStudent(regNo, name, dept, event);
                return null;
            }

            @Override
            protected void done() {
                try {
                    get();
                    regNoField.setText("");
                    nameField.setText("");
                    deptField.setText("");
                    statusLabel.setText("Registration saved for " + regNo.trim());
                    JOptionPane.showMessageDialog(EventRegistrationApp.this,
                            "Student registered successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    loadRegistrationsAsync();
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() != null ? ex.getCause() : ex;
                    statusLabel.setText("Registration rejected: " + cause.getMessage());
                    JOptionPane.showMessageDialog(EventRegistrationApp.this,
                            cause.getMessage(), "Registration Error", JOptionPane.WARNING_MESSAGE);
                }
            }
        }.execute();
    }

    private void loadRegistrationsAsync() {
        String selectedFilter = (String) filterCombo.getSelectedItem();
        statusLabel.setText("Loading registrations (Page " + currentPage + ")...");
        new SwingWorker<List<Registration>, Void>() {
            @Override
            protected List<Registration> doInBackground() throws Exception {
                return service.getRegistrations(selectedFilter, currentPage, PAGE_SIZE);
            }

            @Override
            protected void done() {
                try {
                    currentRows = get();
                    tableModel.setRowCount(0);
                    for (Registration r : currentRows) {
                        tableModel.addRow(new Object[]{
                                r.getId(), r.getRegNo(), r.getStudentName(), r.getDepartment(), r.getEventName(), r.getRegisteredAt()
                        });
                    }
                    statusLabel.setText("Loaded " + currentRows.size() + " record(s) | Page " + currentPage);
                } catch (Exception ex) {
                    statusLabel.setText("Database load error.");
                    JOptionPane.showMessageDialog(EventRegistrationApp.this,
                            "Failed to load data: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void exportCsv() {
        JFileChooser chooser = new JFileChooser();
        chooser.setSelectedFile(new File("event_registrations.csv"));
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                service.exportToCsv(currentRows, chooser.getSelectedFile());
                statusLabel.setText("Exported to " + chooser.getSelectedFile().getName());
                JOptionPane.showMessageDialog(this, "CSV exported successfully!", "Export Complete", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage(), "Export Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new EventRegistrationApp().setVisible(true));
    }
}
