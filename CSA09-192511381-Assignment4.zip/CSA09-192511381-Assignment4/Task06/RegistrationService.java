import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

public class RegistrationService {
    private final RegistrationDAO dao = new RegistrationDAO();

    public void registerStudent(String regNo, String name, String dept, String eventName) throws Exception {
        if (regNo == null || !regNo.trim().matches("[A-Za-z0-9]{5,15}")) {
            throw new IllegalArgumentException("Register Number must be 5-15 alphanumeric characters.");
        }
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Student Name cannot be empty.");
        }
        if (dept == null || dept.trim().isEmpty()) {
            throw new IllegalArgumentException("Department cannot be empty.");
        }
        if (eventName == null || eventName.trim().isEmpty()) {
            throw new IllegalArgumentException("Please select a valid event.");
        }

        if (dao.exists(regNo.trim(), eventName.trim())) {
            throw new IllegalStateException("Duplicate Registration: " + regNo.trim() + " is already registered for " + eventName + ".");
        }

        dao.insert(new Registration(0, regNo.trim(), name.trim(), dept.trim(), eventName.trim(), null));
    }

    public List<Registration> getRegistrations(String eventFilter, int page, int pageSize) throws SQLException {
        int offset = Math.max(0, (page - 1) * pageSize);
        return dao.findByEvent(eventFilter, pageSize, offset);
    }

    public void exportToCsv(List<Registration> rows, File file) throws IOException {
        try (PrintWriter pw = new PrintWriter(new FileWriter(file))) {
            pw.println("ID,RegisterNo,StudentName,Department,EventName,RegisteredAt");
            for (Registration r : rows) {
                pw.printf("%d,%s,"%s","%s","%s",%s%n",
                        r.getId(), r.getRegNo(), r.getStudentName(), r.getDepartment(), r.getEventName(), r.getRegisteredAt());
            }
        }
    }
}
