import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class RegistrationDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/campus_events";
    private static final String DB_USER = "root";
    private static final String DB_PWD = "password";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PWD);
    }

    public boolean exists(String regNo, String eventName) throws SQLException {
        String sql = "SELECT 1 FROM registrations WHERE reg_no = ? AND event_name = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, regNo);
            ps.setString(2, eventName);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    public void insert(Registration reg) throws SQLException {
        String sql = "INSERT INTO registrations (reg_no, student_name, department, event_name) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, reg.getRegNo());
            ps.setString(2, reg.getStudentName());
            ps.setString(3, reg.getDepartment());
            ps.setString(4, reg.getEventName());
            ps.executeUpdate();
        }
    }

    public List<Registration> findByEvent(String eventFilter, int limit, int offset) throws SQLException {
        List<Registration> list = new ArrayList<>();
        boolean filterAll = (eventFilter == null || "All Events".equals(eventFilter));
        String sql = filterAll
                ? "SELECT id, reg_no, student_name, department, event_name, registered_at FROM registrations ORDER BY id DESC LIMIT ? OFFSET ?"
                : "SELECT id, reg_no, student_name, department, event_name, registered_at FROM registrations WHERE event_name = ? ORDER BY id DESC LIMIT ? OFFSET ?";

        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            if (filterAll) {
                ps.setInt(1, limit);
                ps.setInt(2, offset);
            } else {
                ps.setString(1, eventFilter);
                ps.setInt(2, limit);
                ps.setInt(3, offset);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Registration(
                            rs.getInt("id"),
                            rs.getString("reg_no"),
                            rs.getString("student_name"),
                            rs.getString("department"),
                            rs.getString("event_name"),
                            rs.getString("registered_at")
                    ));
                }
            }
        }
        return list;
    }
}
