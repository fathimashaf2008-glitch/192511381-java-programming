import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class FeeService {
    private static final String URL = "jdbc:mysql://localhost:3306/college_db";
    private static final String USER = "root";
    private static final String PWD = "password";

    public void validate(String regNo, String amountText) throws IllegalArgumentException {
        if (regNo == null || regNo.trim().isEmpty()) {
            throw new IllegalArgumentException("Register number cannot be empty.");
        }
        if (!regNo.trim().matches("[A-Za-z0-9]{5,15}")) {
            throw new IllegalArgumentException("Invalid register number format.");
        }
        double amount;
        try {
            amount = Double.parseDouble(amountText.trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Amount must be a valid number.");
        }
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
    }

    public String processPayment(String regNo, double amount) throws SQLException, InterruptedException {
        String sql = "INSERT INTO fees (reg_no, amount) VALUES (?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USER, PWD);
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, regNo.trim());
            ps.setDouble(2, amount);
            ps.executeUpdate();
        }
        // Simulate bank confirmation delay off the EDT
        Thread.sleep(3000);
        return "RCPT-" + System.currentTimeMillis();
    }
}
