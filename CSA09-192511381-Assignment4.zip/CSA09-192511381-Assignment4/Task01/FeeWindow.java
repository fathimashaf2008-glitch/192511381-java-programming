import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

public class FeeWindow extends JFrame {
    private final JTextField regNoField = new JTextField(15);
    private final JTextField amountField = new JTextField(15);
    private final JButton payBtn = new JButton("Pay");
    private final JButton clearBtn = new JButton("Clear");
    private final JButton receiptBtn = new JButton("Receipt");
    private final JLabel statusLabel = new JLabel("Ready");
    private final FeeService feeService = new FeeService();
    private String lastReceipt = null;

    public FeeWindow() {
        super("Student Fee Payment - Fathima Shafreena. F (192511381)");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(2, 2, 8, 8));
        formPanel.setBorder(BorderFactory.createEmptyBorder(12, 12, 4, 12));
        formPanel.add(new JLabel("Register Number:"));
        formPanel.add(regNoField);
        formPanel.add(new JLabel("Fee Amount (INR):"));
        formPanel.add(amountField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        buttonPanel.add(payBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(receiptBtn);

        JPanel statusPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.setBorder(BorderFactory.createEmptyBorder(0, 12, 8, 12));
        statusPanel.add(statusLabel);

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(statusPanel, BorderLayout.SOUTH);

        payBtn.addActionListener(e -> handlePay());
        clearBtn.addActionListener(e -> handleClear());
        receiptBtn.addActionListener(e -> handleReceipt());

        pack();
        setLocationRelativeTo(null);
    }

    private void handlePay() {
        String regNo = regNoField.getText();
        String amtText = amountField.getText();
        try {
            feeService.validate(regNo, amtText);
        } catch (IllegalArgumentException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Validation Error", JOptionPane.WARNING_MESSAGE);
            return;
        }

        double amount = Double.parseDouble(amtText.trim());
        payBtn.setEnabled(false);
        statusLabel.setText("Processing payment with bank...");

        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() throws Exception {
                return feeService.processPayment(regNo, amount);
            }

            @Override
            protected void done() {
                payBtn.setEnabled(true);
                try {
                    lastReceipt = get();
                    statusLabel.setText("Paid! Receipt ID: " + lastReceipt);
                    JOptionPane.showMessageDialog(FeeWindow.this,
                            "Payment successful!\nReceipt No: " + lastReceipt,
                            "Payment Confirmed", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    statusLabel.setText("Payment failed.");
                    JOptionPane.showMessageDialog(FeeWindow.this,
                            "Payment Error: " + ex.getCause().getMessage(),
                            "Database / Bank Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    private void handleClear() {
        regNoField.setText("");
        amountField.setText("");
        statusLabel.setText("Cleared.");
    }

    private void handleReceipt() {
        if (lastReceipt == null) {
            JOptionPane.showMessageDialog(this, "No completed payment in this session.", "Receipt", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "Official Fee Receipt\nReceipt ID: " + lastReceipt +
                    "\nRegister No: " + regNoField.getText().trim() +
                    "\nAmount Paid: INR " + amountField.getText().trim(),
                    "Fee Receipt", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new FeeWindow().setVisible(true));
    }
}
