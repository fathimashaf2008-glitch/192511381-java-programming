import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

/**
 * Demonstrates Styles (a), (b), and (c) for Task 5.1 & 5.2
 */
public class ConverterVariants extends JFrame implements ActionListener {
    private final JTextField amount = new JTextField(10);
    private final JComboBox<String> target = new JComboBox<>(new String[]{"USD", "EUR"});
    private final JLabel result = new JLabel("");

    public ConverterVariants(String style) {
        super("Currency Converter - " + style);
        setLayout(new FlowLayout());
        JButton convertButton = new JButton("Convert");
        add(new JLabel("INR"));
        add(amount);
        add(target);
        add(convertButton);
        add(result);

        if ("A".equals(style)) {
            // Style (a): Frame implements ActionListener
            convertButton.addActionListener(this);
            amount.addActionListener(this);
        } else if ("B".equals(style)) {
            // Style (b): Named Inner Class
            ActionListener named = new ConvertHandler();
            convertButton.addActionListener(named);
            amount.addActionListener(named);
        } else {
            // Style (c): Anonymous Inner Class
            ActionListener anon = new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    performConvert();
                }
            };
            convertButton.addActionListener(anon);
            amount.addActionListener(anon);
        }

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        pack();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        performConvert();
    }

    private class ConvertHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            performConvert();
        }
    }

    private void performConvert() {
        try {
            double inr = Double.parseDouble(amount.getText().trim());
            String curr = (String) target.getSelectedItem();
            double rate = "USD".equals(curr) ? 0.012 : 0.011;
            String out = String.format("%.2f %s", inr * rate, curr);
            result.setText(out);
            JOptionPane.showMessageDialog(this, out);
        } catch (NumberFormatException ex) {
            result.setText("Invalid amount");
            JOptionPane.showMessageDialog(this, "Invalid amount");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ConverterVariants("B").setVisible(true));
    }
}
