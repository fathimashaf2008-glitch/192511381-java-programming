import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class TicketBuilderBenchmark {

    static String[] generateFields(int numFields) {
        String[] fields = new String[numFields];
        for (int i = 0; i < numFields; i++) {
            fields[i] = "Field" + i + ":VAL" + (1000 + i);
        }
        return fields;
    }

    static String buildWithStringConcat(String[] fields) {
        String ticket = "";
        for (int i = 0; i < fields.length; i++) {
            ticket = ticket + fields[i] + "|";
        }
        return ticket;
    }

    static String buildWithStringBuilder(String[] fields) {
        StringBuilder sb = new StringBuilder(fields.length * 16);
        for (int i = 0; i < fields.length; i++) {
            sb.append(fields[i]).append('|');
        }
        return sb.toString();
    }

    static String buildWithStringBuffer(String[] fields) {
        StringBuffer sb = new StringBuffer(fields.length * 16);
        for (int i = 0; i < fields.length; i++) {
            sb.append(fields[i]).append('|');
        }
        return sb.toString();
    }

    static String buildWithStringJoin(String[] fields) {
        return String.join("|", fields) + "|";
    }

    static String buildWithStringJoiner(String[] fields) {
        StringJoiner sj = new StringJoiner("|", "", "|");
        for (String f : fields) {
            sj.add(f);
        }
        return sj.toString();
    }

    static String buildWithStringFormat(String[] fields) {
        StringBuilder fmt = new StringBuilder();
        for (int i = 0; i < fields.length; i++) {
            fmt.append("%s|");
        }
        return String.format(fmt.toString(), (Object[]) fields);
    }

    static long getUsedMemory() {
        System.gc();
        try { Thread.sleep(20); } catch (InterruptedException ignored) {}
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    static void runWorkload(String label, int tickets, int fieldsPerTicket, int runs) {
        String[] fields = generateFields(fieldsPerTicket);

        for (int w = 0; w < 200; w++) {
            buildWithStringConcat(fields);
            buildWithStringBuilder(fields);
            buildWithStringBuffer(fields);
        }

        long estConcatStrings = (long) tickets * (fieldsPerTicket * 2);
        long estBuilderStrings = (long) tickets * 1;

        long memBeforeConcat = getUsedMemory();
        long totalConcatNs = 0;
        int sink = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            for (int t = 0; t < tickets; t++) {
                sink += buildWithStringConcat(fields).length();
            }
            totalConcatNs += (System.nanoTime() - t0);
        }
        long memAfterConcat = getUsedMemory();

        long memBeforeSB = getUsedMemory();
        long totalSBKs = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            for (int t = 0; t < tickets; t++) {
                sink += buildWithStringBuilder(fields).length();
            }
            totalSBKs += (System.nanoTime() - t0);
        }
        long memAfterSB = getUsedMemory();

        long memBeforeSBuf = getUsedMemory();
        long totalSBufNs = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            for (int t = 0; t < tickets; t++) {
                sink += buildWithStringBuffer(fields).length();
            }
            totalSBufNs += (System.nanoTime() - t0);
        }
        long memAfterSBuf = getUsedMemory();

        long tJoin0 = System.nanoTime();
        for (int r = 0; r < runs; r++) {
            for (int t = 0; t < tickets; t++) {
                sink += buildWithStringJoin(fields).length();
            }
        }
        long avgJoinNs = (System.nanoTime() - tJoin0) / runs;

        if (sink == -1) System.out.println(sink);

        double avgConcatMs = (totalConcatNs / (double) runs) / 1_000_000.0;
        double avgSBMs = (totalSBKs / (double) runs) / 1_000_000.0;
        double avgSBufMs = (totalSBufNs / (double) runs) / 1_000_000.0;
        double avgJoinMs = avgJoinNs / 1_000_000.0;

        System.out.printf("Workload: %s (tickets=%d, fields=%d, avg over %d runs)%n",
                label, tickets, fieldsPerTicket, runs);
        System.out.printf("  String (+)    : %8.3f ms | Est. String objs: %10d | Delta Mem: %+d KB%n",
                avgConcatMs, estConcatStrings, (memAfterConcat - memBeforeConcat) / 1024);
        System.out.printf("  StringBuilder : %8.3f ms | Est. String objs: %10d | Delta Mem: %+d KB%n",
                avgSBMs, estBuilderStrings, (memAfterSB - memBeforeSB) / 1024);
        System.out.printf("  StringBuffer  : %8.3f ms | Est. String objs: %10d | Delta Mem: %+d KB%n",
                avgSBufMs, estBuilderStrings, (memAfterSBuf - memBeforeSBuf) / 1024);
        System.out.printf("  String.join() : %8.3f ms (Alternative single-pass delimiter join)%n", avgJoinMs);
        System.out.printf("  Speedup (String+ vs StringBuilder): %.2fx%n%n", avgConcatMs / Math.max(avgSBMs, 0.0001));
    }

    static void demonstrateMultithreadedBookingServer() throws InterruptedException {
        System.out.println("--- Multithreaded Booking Server Demo ---");
        StringBuffer sharedBookingLog = new StringBuffer();
        int threads = 8;
        int bookingsPerThread = 250;
        ExecutorService pool = Executors.newFixedThreadPool(threads);

        for (int th = 0; th < threads; th++) {
            final int workerId = th;
            pool.submit(() -> {
                for (int b = 0; b < bookingsPerThread; b++) {
                    StringBuilder ticket = new StringBuilder();
                    ticket.append("PNR-").append(workerId).append("-").append(b)
                          .append("|TRAIN:12627|COACH:B2|BERTH:").append((b % 72) + 1);
                    sharedBookingLog.append(ticket).append("\n");
                }
            });
        }
        pool.shutdown();
        pool.awaitTermination(5, TimeUnit.SECONDS);
        String[] lines = sharedBookingLog.toString().split("\n");
        System.out.println("Total log entries recorded safely in shared StringBuffer: " + lines.length
                + " (Expected: " + (threads * bookingsPerThread) + ")");
    }

    static void verifySampleInputFile(String path) {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            List<String> list = new ArrayList<>();
            String line;
            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) list.add(line.trim());
            }
            String[] sampleFields = list.toArray(new String[0]);
            System.out.println("--- Sample Ticket from input/sample_ticket_fields.txt ---");
            System.out.println("StringBuilder : " + buildWithStringBuilder(sampleFields));
            System.out.println("StringJoiner  : " + buildWithStringJoiner(sampleFields));
            System.out.println("String.format : " + buildWithStringFormat(sampleFields));
            System.out.println();
        } catch (Exception e) {
            System.out.println("Input file note: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Q1: Railway e-Ticket Generation Benchmark ===\n");
        verifySampleInputFile("input/sample_ticket_fields.txt");
        runWorkload("W1 - Short Ticket (Low Load)", 100, 8, 10);
        runWorkload("W2 - Standard Batch (10,000 tickets x 50 fields)", 10000, 50, 5);
        runWorkload("W3 - Heavy Manifest (2,000 tickets x 250 fields)", 2000, 250, 5);
        demonstrateMultithreadedBookingServer();
    }
}
