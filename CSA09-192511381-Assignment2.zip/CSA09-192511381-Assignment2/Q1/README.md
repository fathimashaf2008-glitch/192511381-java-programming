# Q1 – Building Text Under Load: String, StringBuilder or StringBuffer?

**Student:** Fathima Shafreena F  |  **Register No.:** 192511381

## Contents
- `src/TicketBuilderBenchmark.java`: Benchmarks `String` (`+`), `StringBuilder`, `StringBuffer`, and `String.join()` across three workloads plus a multithreaded booking server simulation.
- `input/sample_ticket_fields.txt`: Sample railway e-ticket fields.
- `output/`: Console output log and terminal screenshot.

## Compile and Run
```sh
sh run.sh
```

## Result Summary
`StringBuilder` achieves a 34.63x speedup on 10,000 tickets x 50 fields and 160.64x speedup on 2,000 tickets x 250 fields by avoiding O(n^2) intermediate `String` allocations. Use `StringBuilder` per thread for ticket construction and `StringBuffer` for the shared multithreaded booking log.
