# CSA09-192511381-Assignment2

**CO2 Analysis & Design Evaluation: Strings, Regular Expressions, Collections Framework, Generics & Comparators**

Student: Fathima Shafreena F  |  Register Number: 192511381  |  Course: Java Programming (CO2)  |  SIMATS Engineering

GitHub Repository: https://github.com/fathimashaf2008-glitch/192511381-java-programming

Compiled and run with Java 21.0.12.1

## Folder Layout

Each task has its own folder matching the standard submission layout:

```
Q1/ .. Q7/
  src/       Java source code
  input/     Input datasets (where applicable)
  output/    Program output (*_output.txt) and console screenshots (*_console.png)
  README.md  Task overview, compile/run steps, and result summary
  run.sh     Compile and run script
```

| Folder | Question / Topic | Main Source Files |
|---|---|---|
| [Q1](Q1/) | Building Text Under Load: String, StringBuilder or StringBuffer? | `TicketBuilderBenchmark.java` |
| [Q2](Q2/) | When Is ArrayList an Appropriate Engineering Choice? | `PlaylistBenchmark.java` |
| [Q3](Q3/) | Engineer the hashCode-equals Contract | `AttendanceBroken.java`, `Attendance.java`, `HashContractInvestigation.java` |
| [Q4](Q4/) | Choosing a Map for a Pharmacy Inventory | `PharmacyInventoryBenchmark.java` |
| [Q5](Q5/) | Derive a Generic Ranking Component from a Principle | `LeaderboardDemo.java`, `GenericRankingTest.java` |
| [Q6](Q6/) | Priority, Order and Fairness in a Queue | `Triage.java`, `TriageAnalysis.java` |
| [Q7](Q7/) | Day-4 Design Challenge: Diagnose, Redesign and Validate | `PharmacyRedesignValidation.java` |

## Complete Assignment Report

See [`ASSIGNMENT2_REPORT.md`](ASSIGNMENT2_REPORT.md) in the root folder for the complete written report covering predictions, experimental tables, Big-O complexity analyses, and Q7 Day-4 Design Challenge evaluation.

## Running

Requires JDK 17 or later.

```sh
cd Q1
sh run.sh
```
