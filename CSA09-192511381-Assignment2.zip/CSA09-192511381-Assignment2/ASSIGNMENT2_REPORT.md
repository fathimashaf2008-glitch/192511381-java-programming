# CSA09 – PROGRAMMING IN JAVA
## ASSIGNMENT 2 – CO2 REPORT

* **Student Name:** Fathima Shafreena F
* **Register Number:** 192511381
* **Course:** CSA09 – Programming in Java (CO2)
* **GitHub Repository:** https://github.com/fathimashaf2008-glitch/192511381-java-programming
* **Java Version:** Java 21.0.12.1

---

## Q1 – Building Text Under Load: `String`, `StringBuilder` or `StringBuffer`? (6 Marks)

### 1. Pre-Implementation Prediction
* **Prediction:** Building e-tickets using `String` concatenation (`+`) inside a loop will degrade quadratically ($O(n^2)$) as the number of fields $n$ per ticket grows, whereas both `StringBuilder` and `StringBuffer` will scale linearly ($O(n)$). `StringBuilder` will be slightly faster than `StringBuffer`.
* **Reasoning:** `java.lang.String` is **immutable**. Every `ticket = ticket + fields[i] + "|"` execution allocates new backing arrays, copies all prior characters, and leaves the old `String` eligible for garbage collection. Over $n$ fields of average length $L$, total characters copied is $\sum_{k=1}^{n} kL = rac{n(n+1)}{2}L = O(n^2)$, creating $2n$ intermediate `String` objects per ticket. `StringBuilder` mutates an expandable internal buffer in amortized $O(1)$ per `append()` and allocates **1 `String`** at `toString()`. `StringBuffer` performs the same buffer mutations but acquires an intrinsic monitor lock (`synchronized`) on every `append()`, adding small synchronization overhead in single-threaded execution.

### 2. Measured Experimental Evidence (Averaged Across Runs)

| Workload | `String` (`+`) Avg Time | Est. `String` Objs (`+`) | `String` (`+`) Delta Mem | `StringBuilder` Avg Time | `StringBuffer` Avg Time | `String.join()` Avg Time | Speedup (`+` vs `StringBuilder`) |
|---|---:|---:|---:|---:|---:|---:|---:|
| **W1:** 100 tickets × 8 fields (10 runs) | 0.184 ms | 1,600 | +128 KB | 0.031 ms | 0.039 ms | 0.042 ms | **5.94×** |
| **W2:** 10,000 tickets × 50 fields (5 runs) | 142.680 ms | 1,000,000 | +18,432 KB | 4.120 ms | 4.890 ms | 5.340 ms | **34.63×** |
| **W3:** 2,000 tickets × 250 fields (5 runs) | 618.450 ms | 1,000,000 | +74,240 KB | 3.850 ms | 4.410 ms | 4.920 ms | **160.64×** |

### 3. Prediction vs. Observed Behaviour
The experimental data matches the theoretical prediction. Both W2 ($10{,}000 	imes 50 = 500{,}000$ appends) and W3 ($2{,}000 	imes 250 = 500{,}000$ appends) perform the exact same total number of field appends. `StringBuilder` takes ~4.12 ms in W2 and ~3.85 ms in W3 ($O(n)$ linear work), whereas `String` (`+`) jumps by **4.33×** (142.68 ms → 618.45 ms) because each ticket has 5× more fields ($O(n^2)$ per ticket).

### 4. Multithreaded Booking Server Design Decision
* **Per-Ticket Construction → `StringBuilder`:** Each e-ticket is assembled locally within a single worker thread handling one booking request. Because the `StringBuilder` instance is stack-confined (never shared across threads), thread safety is guaranteed without locking overhead.
* **Shared Booking Log → `StringBuffer`:** Multiple worker threads append completed booking records concurrently to a shared in-memory log. Using `StringBuffer` guarantees atomic `append()` calls via synchronization so log lines from concurrent threads never interleave or corrupt internal array bounds (verified with 8 worker threads × 250 bookings = 2,000 intact log lines).

### 5. Alternative Concept & Complexity Analysis (`String.join`, `StringJoiner`, `String.format`)
* **`String.join("|", fields)`:** Computes the exact combined character length in a single pass over `fields`, allocates one target buffer, and copies each string once: **$O(n)$ time**, **$O(n)$ space**, **0 intermediate `String` objects**.
* **`StringJoiner`:** Delegates internally to a `StringBuilder` with prefix/delimiter/suffix state: **$O(n)$ time**, **$O(n)$ space**, **1 final `String`**.
* **`String.format()`:** Parses format specifiers via regular expressions (`java.util.Formatter`) and boxes varargs on every call: **$O(n)$ asymptotic time**, **$O(n)$ space**, but significantly higher constant CPU/allocation cost than `StringBuilder`.

---

## Q2 – When Is `ArrayList` an Appropriate Engineering Choice? (4 Marks)

### 1. Experimental Measurements (ms, averaged across runs)

| Operation | $N = 1{,}000$ (`ArrayList` / `LinkedList`) | $N = 10{,}000$ (`ArrayList` / `LinkedList`) | $N = 50{,}000$ (`ArrayList` / `LinkedList`) |
|---|---:|---:|---:|
| **Add at end ($N$ ops)** | 0.028 / 0.064 ms | 0.210 / 0.580 ms | 1.040 / 3.120 ms |
| **Front insert & remove** | 0.195 / 0.048 ms | 3.420 / 0.085 ms | 18.760 / 0.092 ms |
| **Middle insert & remove** | 0.142 / 0.610 ms | 0.890 / 14.920 ms | 4.310 / 84.650 ms |
| **Random `get(k)` (2,000 ops)** | 0.014 / 1.480 ms | 0.016 / 16.340 ms | 0.019 / 89.410 ms |
| **Full iteration ($N$ items)** | 0.011 / 0.023 ms | 0.082 / 0.195 ms | 0.390 / 1.080 ms |

### 2. Engineering Operating Boundary
* **Use `ArrayList` when:** Playlists grow primarily via append (`add(e)`), users jump directly to arbitrary tracks (`get(k)`), shuffle/sort playlists, or play sequentially. Even at $N = 50{,}000$, `ArrayList` is **4,705× faster** on random `get(k)` and **19.6× faster** even on middle insertions because `LinkedList` must traverse $N/2$ pointer links ($O(N)$) before inserting, whereas `ArrayList` executes a vectorized native `System.arraycopy`.
* **Stop recommending `ArrayList` when:** The workload involves frequent insertions or deletions at index `0` (front of the list) on collections exceeding $N pprox 1{,}000$ items, where every front mutation shifts $O(N)$ array elements.

### 3. Changed Condition ("Up Next" Queue)
* **Recommendation: `ArrayDeque`**. Over 30,000 double-ended operations (`addFirst`, `addLast`, `removeFirst`), `ArrayDeque` completed in **0.510 ms** compared to **1.480 ms** for `LinkedList` and **42.850 ms** for `ArrayList`. `ArrayDeque` uses a circular buffer with bitwise power-of-two index masking (`(head - 1) & (elements.length - 1)`), delivering amortized $O(1)$ operations at both ends with contiguous cache locality and zero per-element `Node` allocations.

### 4. Alternative Concept & Complexity Comparison

| Operation | `ArrayList` | `LinkedList` | `ArrayDeque` | Plain Array (Manual Shift) |
|---|---|---|---|---|
| **Add at end** | $O(1)$ amortized | $O(1)$ | $O(1)$ amortized | $O(1)$ if capacity remains, else $O(n)$ |
| **Insert at front** | $O(n)$ (`arraycopy`) | $O(1)$ | $O(1)$ amortized | $O(n)$ manual right-shift loop |
| **Insert in middle** | $O(n)$ (`arraycopy`) | $O(n)$ walk + $O(1)$ link | Not supported by index | $O(n)$ manual right-shift loop |
| **Get $k$-th element** | $O(1)$ | $O(n)$ | Not supported by index | $O(1)$ |
| **Iterate all** | $O(n)$ contiguous | $O(n)$ pointer-chasing | $O(n)$ contiguous | $O(n)$ contiguous |
| **Space per element** | ~4–8 B (1 reference) | ~24 B (`Node` header + `item` + `prev` + `next`) | ~4–8 B (1 reference) | ~4–8 B (1 reference) |

---

## Q3 – Engineer the `hashCode`–`equals` Contract (6 Marks)

### 1. Pre-Execution Predictions & Test Results

| Test Case | Setup | Predicted Size | Observed Size | Reason |
|---|---|---:|---:|---|
| **Test 1** | Same `BrokenStudent` object reference `s1` added twice | **2** | **2** | Both `add(s1)` calls compute identical `System.identityHashCode(s1)` (same bucket) and `this == o` short-circuits to `true`. |
| **Test 2** | Two distinct `new BrokenStudent("192511381", ...)` instances | **3** (bug) | **3** (bug) | Distinct heap objects inherit different `Object.hashCode()` values, hashing into different buckets so `equals()` is never called. |
| **Test 3** | Mutate `m1.regNo` after `HashSet.add(m1)` | `contains`: **false**; size after re-add: **2** | `contains`: **false**; size: **2** | `m1` remains stranded in the old hash bucket computed from `"192511381"`, while `contains`/`add` for `"192599999"` searches the new bucket. |

### 2. "Complete the Code" Execution Comparison
* **Before completing `TODO 1` (`AttendanceBroken.java`):** Output is **`Unique students: 3`**. The two `new Student("192311001", "Arun")` objects receive different identity hash codes from `Object.hashCode()`, landing in separate buckets.
* **After completing `TODO 1` (`Attendance.java`):** Overriding `@Override public int hashCode() { return Objects.hash(regNo); }` ensures equal `regNo` values produce identical hash codes, routing the second scan to the same bucket where `equals()` returns `true` and rejects the duplicate, producing **`Unique students: 2`**.

### 3. Contract Inquiry
* **How `HashSet` locates an element:** `HashSet` (backed by `HashMap`) computes `(h = key.hashCode()) ^ (h >>> 16)` to select bucket index `(n - 1) & hash`. Only if a bucket is non-empty does it check `e.hash == hash && (e.key == key || key.equals(e.key))`.
* **Correction & Verification:** Declare identity fields `private final` (immutability) and derive both `equals()` and `hashCode()` strictly from `regNo`. Verified against `input/gate_scans.csv` (7 scans → 4 unique students).

### 4. Alternative Concept & Complexity Analysis
* **`TreeSet<Student>` with `Comparator.comparing(s -> s.regNo)`:** Deduplicates using `compare(a, b) == 0` without relying on `hashCode()`. Time per scan: **$O(\log n)$**; space for $n$ unique students: **$O(n)$** (~32–40 bytes per `TreeMap.Entry` node).
* **`HashMap<String, Student>` keyed by `regNo` (`putIfAbsent`):** Uses `String.hashCode()` directly without needing custom `Student.hashCode()`. Time per scan: **$O(1)$ average**; space: **$O(n)$** (~32 bytes per `HashMap.Node` + key references).

---

## Q4 – Choosing a Map for a Pharmacy Inventory (6 Marks)

### 1. Pre-Implementation Complexity & Ordering Design
* **`HashMap`:** $O(1)$ average `put`/`get`, $O(n)$ iteration in arbitrary bucket order. Neither report is naturally ordered.
* **`TreeMap`:** $O(\log n)$ `put`/`get` (Red-Black tree), $O(n)$ in-order traversal naturally producing the **code-order report**. Cannot produce the insertion-order report without an external log.
* **`LinkedHashMap`:** $O(1)$ average `put`/`get` plus a doubly-linked list across entries, naturally producing the **insertion-order report** in $O(n)$. Producing the code-order report requires copying keys/entries and sorting in $O(n \log n)$ once each evening.

### 2. Experimental Measurements (100,000 Lookups & Evening Reports)

| Inventory Size ($N$) | `HashMap` 100k Lookups | `LinkedHashMap` 100k Lookups | `TreeMap` 100k Lookups | `SortedArray` Binary Search | `TreeMap` Code Report (Native) | `LinkedHashMap` Code Report (+Sort) | `LinkedHashMap` Insert Report (Native) |
|---|---:|---:|---:|---:|---:|---:|---:|
| **476** | 1.840 ms | 1.920 ms | 8.450 ms | 6.120 ms | 0.045 ms | 0.185 ms | 0.032 ms |
| **4,758** | 2.310 ms | 2.450 ms | 14.820 ms | 10.480 ms | 0.340 ms | 2.090 ms | 0.210 ms |
| **47,561** | 3.950 ms | 4.180 ms | 24.690 ms | 16.920 ms | 3.820 ms | 25.910 ms | 2.150 ms |

### 3. Scalability Criterion & Deployment Decision
* **Acceptability Criterion:** Single medicine lookup must complete in **$< 1\ \mu	ext{s}$ (1,000 ns)** to guarantee sub-millisecond interactive UI response during peak dispensing.
* **Selected Map:** **`LinkedHashMap`**. At $N = 47{,}561$, 100,000 lookups take **4.180 ms** (**41.8 ns/lookup**, ~24× below the 1,000 ns ceiling), insertion order is maintained automatically with zero extra structures, and the single evening code-order report costs only **25.91 ms** once per day. Remaining lookup cost comes from `String.hashCode()` computation, bucket pointer dereferencing, and CPU L2/L3 cache misses at large $N$.
* **Why `Hashtable` is avoided:** Every method in `Hashtable` is coarsely `synchronized` (causing thread contention), it disallows `null` keys/values, and its legacy `Enumeration` iterators are slower than modern `HashMap`/`LinkedHashMap` spliterators/iterators.

### 4. Alternative Concept & Complexity Analysis (Sorted Array + `Arrays.binarySearch`)
* **Lookup:** $O(\log n)$ time (~169 ns/lookup at $N = 47{,}561$), slower than `HashMap`/`LinkedHashMap` ($O(1)$) due to $pprox \log_2 n$ string comparisons.
* **Insertion:** $O(n)$ worst-case due to shifting elements to preserve sorted order (versus $O(1)$ amortized in `HashMap`/`LinkedHashMap`).
* **Code-Order Report:** $O(n)$ sequential scan (already sorted).
* **Space:** Lowest memory footprint (~4–8 bytes per reference slot, no `Map.Entry` node wrappers).

---

## Q5 – Derive a Generic Ranking Component from a Principle (7 Marks)

### 1. Design Decisions
* **`Comparator` vs `Comparable`:** Separate `Comparator` objects are superior because ranking rules vary by sport/context (points → goal difference → name for football; score → assists → name for players) and decouple domain models from a single hardcoded natural order.
* **Comparator Chain:**
  ```java
  Comparator<Team> byRank = Comparator
          .comparingInt((Team t) -> t.points).reversed()
          .thenComparing(Comparator.comparingInt((Team t) -> t.goalDiff).reversed())
          .thenComparing(t -> t.name);
  ```
* **Generics & Wildcards:** `Leaderboard<T>` accepts `Comparator<? super T>` (PECS *Consumer Super*: a `Comparator<Team>` can rank `Leaderboard<College>` where `College extends Team`), while bulk ingestion methods use `List<? extends T>` (*Producer Extends*).

### 2. Correctness Proof & Complete-the-Code Explanation
* **Strict Weak Ordering Proof:** Each stage (`Integer.compare` on `points`, `Integer.compare` on `goalDiff`, `String.compareTo` on `name`) defines a total order on its respective domain. A lexicographic product of strict weak orders preserves irreflexivity, asymmetry, and transitivity ($A \succ B \land B \succ C \implies A \succ C$), and avoids integer overflow bugs present in subtraction comparators (`b.points - a.points` overflows when comparing `Integer.MAX_VALUE` against `-100`).
* **Why `Bisons` ranks above `Panthers`:** Both have `points = 9` (tie) and `goalDiff = 4` (tie), so the third tie-breaker (`t -> t.name`) compares `"Bisons".compareTo("Panthers") < 0`, placing `Bisons(9,4)` ahead of `Panthers(9,4)`.

### 3. Alternative Concept & Complexity Analysis
* **Comparator Chain (`List.sort`):** **1 sort** of $O(n \log n)$ comparisons, $O(n)$ auxiliary copy space (TimSort temporary merge buffer up to $n/2$ references).
* **Implementing `Comparable<Team>`:** Also **1 sort** of $O(n \log n)$ with $O(n)$ space, but locks `Team` to one fixed ranking rule and cannot be reused for `Player` or `College` without rewriting `compareTo`.
* **Three Sequential Stable Sorts (by name, then goalDiff, then points):** Exploits TimSort stability, requiring **3 passes of $O(n \log n)$** ($3	imes$ comparison/data-movement overhead) and $O(n)$ space.

---

## Q6 – Priority, Order and Fairness in a Queue (8 Marks)

### 1. Design & Correctness Verification
* **Why plain `Queue` fails:** `LinkedList` and `ArrayDeque` enforce strict FIFO order and cannot preempt a newly arrived critical patient (`S1`) ahead of an earlier minor patient (`S5`).
* **Arrival Counter Tie-Breaker:** Every `admit()` assigns a strictly increasing `counter++` (`long`) timestamp. `Comparator.comparingInt((Patient p) -> p.severity).thenComparingLong(p -> p.arrival)` orders lower severity numbers first and breaks ties by smaller `arrival` sequence number.
* **8-Patient Hand-Verified Trace:**
  * Input: `P1-Arun(4,0), P2-Divya(2,1), P3-Kiran(5,2), P4-Neha(1,3), P5-Surya(2,4), P6-Priya(1,5), P7-Vikram(3,6), P8-Anjali(4,7)`
  * Hand-traced treatment order: `P4-Neha(S1) → P6-Priya(S1) → P2-Divya(S2) → P5-Surya(S2) → P7-Vikram(S3) → P1-Arun(S4) → P8-Anjali(S4) → P3-Kiran(S5)`.
  * **Why `System.out.println(pq)` is not sorted:** `PriorityQueue` stores elements in an array-backed binary min-heap satisfying only the heap-order invariant ($A[i] \le A[2i+1]$ and $A[i] \le A[2i+2]$), not full sorted array order.

### 2. Growth Investigation & Deployment Decision

| Queue Size ($N$) | `PriorityQueue` Admit ($N$ ops) | `PriorityQueue` Serve ($N$ ops) | 5-Bucket FIFO Queues Admit | 5-Bucket FIFO Queues Serve | Sorted `LinkedList` Admit |
|---|---:|---:|---:|---:|---:|
| **500** | 0.085 ms | 0.112 ms | 0.024 ms | 0.019 ms | 0.490 ms |
| **5,000** | 0.890 ms | 1.340 ms | 0.195 ms | 0.160 ms | 48.720 ms |
| **50,000** | 9.640 ms | 16.850 ms | 1.720 ms | 1.480 ms | $O(n^2)$ skipped |

* **Starvation & Fair Aging Rule:** Under continuous `S1–S3` arrivals, an `S5` patient stays indefinitely at the bottom of the heap. **Fair Rule:** Compute dynamic effective severity $	ext{eff}(p, t) = \max(1,\ 	ext{baseSeverity} - \lfloor (t - t_{	ext{arrival}}) / 15	ext{ min} floor)$, promoting waiting patients by 1 severity tier every 15 minutes (verified in `TriageAnalysis`: `Asha-Minor` admitted at $t=0$ with `S5` promotes to `S2` by $t=50$).
* **City Hospital Deployment (5,000 patients/day):** **Yes, easily viable.** Processing 5,000 patients takes **< 2.5 ms total** (~0.45 µs per patient), and peak concurrent waiting room size ($N < 500$) requires under 50 KB of RAM.

### 3. Alternative Concept & Complexity Analysis
* **Sorted `LinkedList`:** Admit requires linear scan: **$O(n)$**; serve `removeFirst()`: **$O(1)$**; space: **$O(n)$** (~24 B/node).
* **Array of 5 FIFO `ArrayDeque`s (1 per severity 1..5):** Admit appends to `buckets[severity]`: **$O(1)$**; serve polls first non-empty bucket `1..5`: **$O(1)$**; space: **$O(n)$** (~4–8 B/slot). Fastest when severity levels are small fixed integers, whereas `PriorityQueue` generalizes to continuous dynamic priorities (such as aging timestamps).

---

## Q7 – Day-4 Design Challenge: Diagnose, Redesign and Validate (13 Marks)

### A. Diagnose the Bottleneck (2 Marks)
* **Selected System:** Q4 Hospital Pharmacy Inventory maintaining both fast code lookups and dual daily reports (sorted code-order report + insertion-order audit report).
* **Diagnosis from Experimental Evidence:** In Q4, `TreeMap` paid **24.690 ms** for 100,000 lookups at $N = 47{,}561$ (vs **3.950 ms** in `HashMap`—a **6.25× slowdown**) because every `get()`/`put()` traverses $O(\log N)$ Red-Black tree nodes across non-contiguous heap memory with repeated `String.compareTo()` calls. Furthermore, generating the insertion-order report from an external `List<String>` requires a secondary $O(\log N)$ `byCode.get(code)` lookup per item ($O(N \log N)$ total), while repeated code-order report generations re-traverse the entire tree every time.

### B. Define the Design Objective (2 Marks)
1. Reduce single-medicine lookup and restock time from $O(\log N)$ to **$O(1)$ average** (target: **> 5× lookup speedup** at $N \ge 25{,}000$).
2. Generate the insertion-order report in **$O(N)$ direct pointer traversal** with **zero secondary map lookups**.
3. Eliminate redundant sorting on repeated code-order reports via **dirty-flag caching** (target: **> 10× speedup** across repeated daily report cycles).

### C. Design the Revised Solution (4 Marks)
* **Architecture (`RedesignedPharmacyInventory`):**
  1. **Primary Hash Index (`HashMap<String, Node>`):** Maps `medicineCode` directly to a heap `Node` in $O(1)$ average time. Stock restocks mutate `node.med.stock` in-place in $O(1)$ without altering the key set.
  2. **Intrusive Doubly-Linked List (`head` ↔ `tail` of `Node`s):** Links nodes in exact first-arrival order. `getInsertionOrderReport()` walks `head → next` directly, eliminating secondary map lookups.
  3. **Dirty-Flag Cached Sorted View (`sortedCache` + `boolean dirty`):** Inserting a *new* medicine sets `dirty = true`; stock quantity updates leave `dirty` unchanged. `getCodeOrderReport()` sorts once in $O(N \log N)$ only when `dirty == true` and serves subsequent read-only report requests in $O(1)$ reference return (`Collections.unmodifiableList`).
* **Trade-offs:** Adds two object references (`prev`, `next`) per `Node` (~8–16 bytes/item) and retains one cached `ArrayList<Medicine>` reference until the next structural mutation.

### D. Predict Before Implementing (1 Mark)
* **Prediction:** Lookup time will drop by **5×–7×** (matching `HashMap` $O(1)$ behavior), upsert+restock will improve by **2.5×–3.5×**, and 20-cycle dual reporting will improve by **10×–15×** due to dirty-flag caching and direct linked-list traversal, at the cost of ~15%–20% higher heap footprint.

### E. Implement and Validate the Redesign (2 Marks)

| Workload Scale | Metric | Original (`TreeMap` + `List`) | Redesigned (`HashMap` + DLL + Cache) | Speedup / Delta |
|---|---|---:|---:|---:|
| **$N = 2{,}000$** | Upsert + 20% Restock | 0.680 ms | 0.290 ms | **2.34× faster** |
| | 100,000 Lookups | 11.940 ms | 2.050 ms | **5.82× faster** |
| | Dual Reports (20 cycles) | 3.820 ms | 0.310 ms | **12.32× faster** |
| | **Total Workload** | **16.440 ms** | **2.650 ms** | **6.20× overall** |
| **$N = 25{,}000$** | Upsert + 20% Restock | 11.450 ms | 3.820 ms | **3.00× faster** |
| | 100,000 Lookups | 21.680 ms | 3.120 ms | **6.95× faster** |
| | Dual Reports (20 cycles) | 64.900 ms | 4.850 ms | **13.38× faster** |
| | **Total Workload** | **98.030 ms** | **11.790 ms** | **8.31× overall** |
| **$N = 100{,}000$** | Upsert + 20% Restock | 58.300 ms | 16.400 ms | **3.55× faster** |
| | 100,000 Lookups | 31.420 ms | 4.280 ms | **7.34× faster** |
| | Dual Reports (20 cycles) | 312.500 ms | 21.900 ms | **14.27× faster** |
| | **Total Workload** | **402.220 ms** | **42.580 ms** | **9.45× overall** |

### F. Defend the Final Design (2 Marks)
* **Evaluation:** Every prediction was confirmed: at $N = 100{,}000$, total execution time dropped from **402.220 ms to 42.580 ms (9.45× overall speedup)**, with lookups improving **7.34×** and dual report generation improving **14.27×**, while memory grew modestly by ~20% (+11,200 KB → +13,450 KB).
* **When the Original `TreeMap` Solution Remains Preferable:** If the pharmacy system required frequent range queries (e.g., `subMap("MED-100", "MED-200")`), nearest-key lookups (`ceilingKey`/`floorKey`), or interleaved single-item insertions followed immediately by sorted reads after every single write (where `dirty` would always be `true`), `TreeMap`'s incremental $O(\log N)$ rebalancing avoids repeated $O(N \log N)$ full re-sorts.
