import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

public class PharmacyRedesignValidation {

    static class Medicine {
        final String code;
        final String name;
        int stock;

        Medicine(String code, String name, int stock) {
            this.code = code;
            this.name = name;
            this.stock = stock;
        }
    }

    static class OriginalPharmacyInventory {
        private final TreeMap<String, Medicine> byCode = new TreeMap<>();
        private final List<String> insertionLog = new ArrayList<>();

        void upsert(String code, String name, int deltaStock) {
            Medicine existing = byCode.get(code);
            if (existing != null) {
                existing.stock += deltaStock;
            } else {
                byCode.put(code, new Medicine(code, name, deltaStock));
                insertionLog.add(code);
            }
        }

        Medicine lookup(String code) {
            return byCode.get(code);
        }

        List<Medicine> getCodeOrderReport() {
            return new ArrayList<>(byCode.values());
        }

        List<Medicine> getInsertionOrderReport() {
            List<Medicine> out = new ArrayList<>(insertionLog.size());
            for (String code : insertionLog) {
                out.add(byCode.get(code));
            }
            return out;
        }
    }

    static class RedesignedPharmacyInventory {
        private static final class Node {
            final Medicine med;
            Node prev, next;
            Node(Medicine med) { this.med = med; }
        }

        private final Map<String, Node> index = new HashMap<>();
        private Node head, tail;
        private List<Medicine> sortedCache = null;
        private boolean dirty = true;

        void upsert(String code, String name, int deltaStock) {
            Node node = index.get(code);
            if (node != null) {
                node.med.stock += deltaStock;
                return;
            }
            Medicine m = new Medicine(code, name, deltaStock);
            Node newNode = new Node(m);
            index.put(code, newNode);
            if (tail == null) {
                head = tail = newNode;
            } else {
                tail.next = newNode;
                newNode.prev = tail;
                tail = newNode;
            }
            dirty = true;
        }

        Medicine lookup(String code) {
            Node n = index.get(code);
            return (n == null) ? null : n.med;
        }

        List<Medicine> getCodeOrderReport() {
            if (dirty || sortedCache == null) {
                List<Medicine> fresh = new ArrayList<>(index.size());
                for (Node cur = head; cur != null; cur = cur.next) {
                    fresh.add(cur.med);
                }
                fresh.sort(Comparator.comparing(m -> m.code));
                sortedCache = fresh;
                dirty = false;
            }
            return Collections.unmodifiableList(sortedCache);
        }

        List<Medicine> getInsertionOrderReport() {
            List<Medicine> out = new ArrayList<>(index.size());
            for (Node cur = head; cur != null; cur = cur.next) {
                out.add(cur.med);
            }
            return out;
        }
    }

    static long getUsedMemory() {
        System.gc();
        try { Thread.sleep(20); } catch (InterruptedException ignored) {}
        Runtime rt = Runtime.getRuntime();
        return rt.totalMemory() - rt.freeMemory();
    }

    static void runComparison(int n, int lookups, int reportCycles, int runs) {
        Random rng = new Random(192511381L);
        String[] codes = new String[n];
        for (int i = 0; i < n; i++) {
            codes[i] = String.format("MED-%07d", rng.nextInt(n * 20));
        }
        String[] queries = new String[lookups];
        for (int i = 0; i < lookups; i++) {
            queries[i] = codes[rng.nextInt(n)];
        }

        OriginalPharmacyInventory wOrig = new OriginalPharmacyInventory();
        RedesignedPharmacyInventory wRed = new RedesignedPharmacyInventory();
        for (int i = 0; i < Math.min(n, 500); i++) {
            wOrig.upsert(codes[i], "Drug" + i, 10);
            wRed.upsert(codes[i], "Drug" + i, 10);
        }

        long origInsertNs = 0, origLookupNs = 0, origReportsNs = 0;
        long redInsertNs = 0, redLookupNs = 0, redReportsNs = 0;
        int sink = 0;

        long memBeforeOrig = getUsedMemory();
        OriginalPharmacyInventory lastOrig = null;
        for (int r = 0; r < runs; r++) {
            OriginalPharmacyInventory orig = new OriginalPharmacyInventory();
            long t0 = System.nanoTime();
            for (int i = 0; i < n; i++) orig.upsert(codes[i], "Drug-" + i, 100);
            for (int i = 0; i < n / 5; i++) orig.upsert(codes[i], "Drug-" + i, 25);
            origInsertNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (String q : queries) sink += orig.lookup(q).stock;
            origLookupNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (int c = 0; c < reportCycles; c++) {
                sink += orig.getCodeOrderReport().size();
                sink += orig.getInsertionOrderReport().size();
            }
            origReportsNs += System.nanoTime() - t0;
            lastOrig = orig;
        }
        long memAfterOrig = getUsedMemory();
        if (lastOrig == null) System.out.println("null");

        long memBeforeRed = getUsedMemory();
        RedesignedPharmacyInventory lastRed = null;
        for (int r = 0; r < runs; r++) {
            RedesignedPharmacyInventory red = new RedesignedPharmacyInventory();
            long t0 = System.nanoTime();
            for (int i = 0; i < n; i++) red.upsert(codes[i], "Drug-" + i, 100);
            for (int i = 0; i < n / 5; i++) red.upsert(codes[i], "Drug-" + i, 25);
            redInsertNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (String q : queries) sink += red.lookup(q).stock;
            redLookupNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (int c = 0; c < reportCycles; c++) {
                sink += red.getCodeOrderReport().size();
                sink += red.getInsertionOrderReport().size();
            }
            redReportsNs += System.nanoTime() - t0;
            lastRed = red;
        }
        long memAfterRed = getUsedMemory();
        if (lastRed == null || sink == -1) System.out.println(sink);

        double oIns = (origInsertNs / (double) runs) / 1e6;
        double rIns = (redInsertNs / (double) runs) / 1e6;
        double oLkp = (origLookupNs / (double) runs) / 1e6;
        double rLkp = (redLookupNs / (double) runs) / 1e6;
        double oRep = (origReportsNs / (double) runs) / 1e6;
        double rRep = (redReportsNs / (double) runs) / 1e6;

        System.out.printf("=== Q7 Validation: N = %d, Lookups = %d, Report Cycles = %d (avg over %d runs) ===%n",
                n, lookups, reportCycles, runs);
        System.out.printf("  Upsert + Restock : Original = %7.3f ms | Redesigned = %7.3f ms (%.2fx faster)%n",
                oIns, rIns, oIns / Math.max(rIns, 0.001));
        System.out.printf("  100k Lookups     : Original = %7.3f ms | Redesigned = %7.3f ms (%.2fx faster)%n",
                oLkp, rLkp, oLkp / Math.max(rLkp, 0.001));
        System.out.printf("  Dual Reports(x%d): Original = %7.3f ms | Redesigned = %7.3f ms (%.2fx faster)%n",
                reportCycles, oRep, rRep, oRep / Math.max(rRep, 0.001));
        System.out.printf("  Total Workload   : Original = %7.3f ms | Redesigned = %7.3f ms (%.2fx overall speedup)%n",
                (oIns + oLkp + oRep), (rIns + rLkp + rRep),
                (oIns + oLkp + oRep) / Math.max((rIns + rLkp + rRep), 0.001));
        System.out.printf("  Memory Footprint : Original Delta = %+d KB | Redesigned Delta = %+d KB%n%n",
                (memAfterOrig - memBeforeOrig) / 1024, (memAfterRed - memBeforeRed) / 1024);
    }

    public static void main(String[] args) {
        System.out.println("=== Q7: Day-4 Design Challenge — Pharmacy Dual-Order Catalog Redesign ===\n");
        runComparison(2_000, 100_000, 20, 5);
        runComparison(25_000, 100_000, 20, 5);
        runComparison(100_000, 100_000, 20, 3);
    }
}
