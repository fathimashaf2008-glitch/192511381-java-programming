#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out PharmacyRedesignValidation | tee output/PharmacyRedesignValidation_output.txt
