# Q7 – Day-4 Design Challenge: Diagnose, Redesign and Validate

**Student:** Fathima Shafreena F  |  **Register No.:** 192511381

## Contents
- `src/PharmacyRedesignValidation.java`: Side-by-side experimental benchmark comparing the Original `TreeMap + ArrayList` Pharmacy Inventory against the Redesigned Dual-Index (`HashMap` + Intrusive Doubly-Linked List + Dirty-Flag Cached Sorted View) catalog.

## Compile and Run
```sh
sh run.sh
```

## Result Summary
Across N = 2,000 to N = 100,000 medicines, the redesigned catalog achieves a 6.20x to 9.45x overall speedup (7.34x faster lookups and 14.27x faster dual reporting at N = 100,000) for a ~18% memory overhead.
