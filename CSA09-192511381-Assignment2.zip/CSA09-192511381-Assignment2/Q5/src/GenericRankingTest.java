import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class GenericRankingTest {

    static class Player {
        final String name;
        final int score;
        final int assists;
        Player(String name, int score, int assists) {
            this.name = name;
            this.score = score;
            this.assists = assists;
        }
        @Override
        public String toString() { return name + "[" + score + "pts," + assists + "ast]"; }
    }

    static class College extends Team {
        final String city;
        College(String name, int points, int goalDiff, String city) {
            super(name, points, goalDiff);
            this.city = city;
        }
        @Override
        public String toString() { return name + "-" + city + "(" + points + "," + goalDiff + ")"; }
    }

    static <T> void addAllItems(Leaderboard<T> board, List<? extends T> batch) {
        for (T item : batch) {
            board.add(item);
        }
    }

    public static void main(String[] args) {
        System.out.println("=== Q5: Generic Ranking Component & Edge-Case Verification ===\n");

        Comparator<Team> teamOrder = Comparator
                .comparingInt((Team t) -> t.points).reversed()
                .thenComparing(Comparator.comparingInt((Team t) -> t.goalDiff).reversed())
                .thenComparing(t -> t.name);

        Leaderboard<Team> multiTieBoard = new Leaderboard<>(teamOrder);
        addAllItems(multiTieBoard, List.of(
                new Team("Titans", 12, 8),
                new Team("Wolves", 12, 8),
                new Team("Hawks", 12, 10),
                new Team("Falcons", 9, 5),
                new Team("Sharks", 9, 5),
                new Team("Lions", 9, -2)
        ));
        System.out.println("Dataset 1 (Multi-level ties):");
        System.out.println("  " + multiTieBoard.ranking() + "\n");

        Team extremeHigh = new Team("Apex", Integer.MAX_VALUE, 10);
        Team extremeLow = new Team("Nadir", -100, 5);
        Comparator<Team> faultySubComparator = (a, b) -> b.points - a.points;

        System.out.println("Dataset 2 (Integer Overflow Trap):");
        System.out.println("  Faulty subtraction compare(Apex, Nadir) : " + faultySubComparator.compare(extremeHigh, extremeLow)
                + " (WRONG: positive means Apex ranks below Nadir due to int overflow!)");
        System.out.println("  Safe Comparator.comparingInt result     : " + teamOrder.compare(extremeHigh, extremeLow)
                + " (CORRECT: negative means Apex ranks above Nadir)\n");

        Comparator<Player> playerOrder = Comparator
                .comparingInt((Player p) -> p.score).reversed()
                .thenComparing(Comparator.comparingInt((Player p) -> p.assists).reversed())
                .thenComparing(p -> p.name);
        Leaderboard<Player> playerBoard = new Leaderboard<>(playerOrder);
        playerBoard.add(new Player("Fathima", 45, 12));
        playerBoard.add(new Player("Arjun", 45, 15));
        playerBoard.add(new Player("Meera", 38, 10));
        System.out.println("Reuse 1 - Player Leaderboard: " + playerBoard.ranking());

        Leaderboard<College> collegeBoard = new Leaderboard<>(teamOrder);
        List<College> colleges = new ArrayList<>();
        colleges.add(new College("HITS", 15, 9, "Chennai"));
        colleges.add(new College("VIT", 15, 11, "Vellore"));
        addAllItems(collegeBoard, colleges);
        System.out.println("Reuse 2 - College Leaderboard (uses Comparator<Team> via ? super T): " + collegeBoard.ranking());
    }
}
