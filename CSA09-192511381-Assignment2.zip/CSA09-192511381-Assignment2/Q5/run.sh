#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out LeaderboardDemo | tee output/LeaderboardDemo_output.txt
java -cp out GenericRankingTest | tee output/GenericRankingTest_output.txt
