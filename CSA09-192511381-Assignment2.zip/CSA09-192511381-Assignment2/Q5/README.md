# Q5 – Derive a Generic Ranking Component from a Principle

**Student:** Fathima Shafreena F  |  **Register No.:** 192511381

## Contents
- `src/LeaderboardDemo.java`: Completed `Leaderboard<T>` and multi-criteria `Comparator<Team>`.
- `src/GenericRankingTest.java`: Multi-tie datasets, integer overflow trap proof, and generic reuse across `Player` and `College` (`<? super T>` and `<? extends T>`).

## Compile and Run
```sh
sh run.sh
```
