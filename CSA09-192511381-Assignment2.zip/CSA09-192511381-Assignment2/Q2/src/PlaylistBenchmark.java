import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class PlaylistBenchmark {

    static class Song {
        final int id;
        final String title;
        Song(int id, String title) {
            this.id = id;
            this.title = title;
        }
    }

    static void benchmarkSize(int n, int runs) {
        Song[] seed = new Song[n];
        for (int i = 0; i < n; i++) {
            seed[i] = new Song(i, "Track-" + i);
        }

        ArrayList<Song> warmA = new ArrayList<>();
        LinkedList<Song> warmL = new LinkedList<>();
        for (int i = 0; i < Math.min(n, 500); i++) {
            warmA.add(seed[i]);
            warmL.add(seed[i]);
        }

        long alAddEnd = 0, llAddEnd = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            List<Song> al = new ArrayList<>();
            for (int i = 0; i < n; i++) al.add(seed[i]);
            alAddEnd += System.nanoTime() - t0;

            t0 = System.nanoTime();
            List<Song> ll = new LinkedList<>();
            for (int i = 0; i < n; i++) ll.add(seed[i]);
            llAddEnd += System.nanoTime() - t0;
        }

        int frontOps = Math.min(n, 2000);
        long alFront = 0, llFront = 0;
        for (int r = 0; r < runs; r++) {
            List<Song> al = new ArrayList<>(List.of(seed));
            long t0 = System.nanoTime();
            for (int i = 0; i < frontOps; i++) al.add(0, seed[i]);
            for (int i = 0; i < frontOps; i++) al.remove(0);
            alFront += System.nanoTime() - t0;

            List<Song> ll = new LinkedList<>(List.of(seed));
            t0 = System.nanoTime();
            for (int i = 0; i < frontOps; i++) ll.add(0, seed[i]);
            for (int i = 0; i < frontOps; i++) ll.remove(0);
            llFront += System.nanoTime() - t0;
        }

        int midOps = Math.min(n, 1000);
        long alMid = 0, llMid = 0;
        for (int r = 0; r < runs; r++) {
            List<Song> al = new ArrayList<>(List.of(seed));
            long t0 = System.nanoTime();
            for (int i = 0; i < midOps; i++) {
                int mid = al.size() / 2;
                al.add(mid, seed[i]);
                al.remove(mid);
            }
            alMid += System.nanoTime() - t0;

            List<Song> ll = new LinkedList<>(List.of(seed));
            t0 = System.nanoTime();
            for (int i = 0; i < midOps; i++) {
                int mid = ll.size() / 2;
                ll.add(mid, seed[i]);
                ll.remove(mid);
            }
            llMid += System.nanoTime() - t0;
        }

        int getOps = 2000;
        int[] indices = new int[getOps];
        Random rng = new Random(42);
        for (int i = 0; i < getOps; i++) indices[i] = rng.nextInt(n);

        List<Song> alFixed = new ArrayList<>(List.of(seed));
        List<Song> llFixed = new LinkedList<>(List.of(seed));
        long alGet = 0, llGet = 0;
        int sink = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            for (int idx : indices) sink += alFixed.get(idx).id;
            alGet += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (int idx : indices) sink += llFixed.get(idx).id;
            llGet += System.nanoTime() - t0;
        }

        long alIter = 0, llIter = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            for (Song s : alFixed) sink += s.id;
            alIter += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (Song s : llFixed) sink += s.id;
            llIter += System.nanoTime() - t0;
        }
        if (sink == -1) System.out.println(sink);

        System.out.printf("=== Playlist Size N = %d (avg over %d runs, in ms) ===%n", n, runs);
        System.out.printf("  %-26s | ArrayList: %8.3f ms | LinkedList: %8.3f ms%n",
                "Add at end (" + n + " ops)", (alAddEnd / (double) runs) / 1e6, (llAddEnd / (double) runs) / 1e6);
        System.out.printf("  %-26s | ArrayList: %8.3f ms | LinkedList: %8.3f ms%n",
                "Front ins/rem (" + frontOps + "x2)", (alFront / (double) runs) / 1e6, (llFront / (double) runs) / 1e6);
        System.out.printf("  %-26s | ArrayList: %8.3f ms | LinkedList: %8.3f ms%n",
                "Middle ins/rem (" + midOps + "x2)", (alMid / (double) runs) / 1e6, (llMid / (double) runs) / 1e6);
        System.out.printf("  %-26s | ArrayList: %8.3f ms | LinkedList: %8.3f ms%n",
                "Random get(k) (" + getOps + " ops)", (alGet / (double) runs) / 1e6, (llGet / (double) runs) / 1e6);
        System.out.printf("  %-26s | ArrayList: %8.3f ms | LinkedList: %8.3f ms%n%n",
                "Full iteration (" + n + " items)", (alIter / (double) runs) / 1e6, (llIter / (double) runs) / 1e6);
    }

    static void benchmarkUpNextQueue(int ops, int runs) {
        System.out.println("=== Changed Condition: 'Up Next' Double-Ended Queue (" + ops + " ops) ===");
        long alNs = 0, llNs = 0, adNs = 0;
        int sink = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            ArrayList<Song> al = new ArrayList<>();
            for (int i = 0; i < ops; i++) {
                if (i % 2 == 0) al.add(0, new Song(i, "Priority"));
                else al.add(new Song(i, "Normal"));
                if (i % 3 == 0 && !al.isEmpty()) sink += al.remove(0).id;
            }
            alNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            Deque<Song> ll = new LinkedList<>();
            for (int i = 0; i < ops; i++) {
                if (i % 2 == 0) ll.addFirst(new Song(i, "Priority"));
                else ll.addLast(new Song(i, "Normal"));
                if (i % 3 == 0 && !ll.isEmpty()) sink += ll.removeFirst().id;
            }
            llNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            Deque<Song> ad = new ArrayDeque<>();
            for (int i = 0; i < ops; i++) {
                if (i % 2 == 0) ad.addFirst(new Song(i, "Priority"));
                else ad.addLast(new Song(i, "Normal"));
                if (i % 3 == 0 && !ad.isEmpty()) sink += ad.removeFirst().id;
            }
            adNs += System.nanoTime() - t0;
        }
        if (sink == -1) System.out.println(sink);

        System.out.printf("  ArrayList  (shift on front ops) : %8.3f ms%n", (alNs / (double) runs) / 1e6);
        System.out.printf("  LinkedList (node alloc per op)  : %8.3f ms%n", (llNs / (double) runs) / 1e6);
        System.out.printf("  ArrayDeque (circular buffer)    : %8.3f ms%n", (adNs / (double) runs) / 1e6);
    }

    public static void main(String[] args) {
        System.out.println("=== Q2: Music Playlist Editor Data Structure Analysis ===\n");
        benchmarkSize(1000, 5);
        benchmarkSize(10000, 5);
        benchmarkSize(50000, 3);
        benchmarkUpNextQueue(30000, 5);
    }
}
