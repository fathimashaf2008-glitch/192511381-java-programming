# Q2 – When Is ArrayList an Appropriate Engineering Choice?

**Student:** Fathima Shafreena F  |  **Register No.:** 192511381

## Contents
- `src/PlaylistBenchmark.java`: Compares `ArrayList` vs `LinkedList` across sizes 1,000, 10,000, and 50,000, and evaluates `ArrayDeque` for the "Up Next" double-ended queue.
- `output/`: Console output log and terminal screenshot.

## Compile and Run
```sh
sh run.sh
```

## Result Summary
`ArrayList` outperforms `LinkedList` on append, middle insert/remove, random `get(k)` access, and iteration due to contiguous memory cache locality. For the double-ended "Up Next" queue, `ArrayDeque` (0.510 ms) outperforms both `LinkedList` (1.480 ms) and `ArrayList` (42.850 ms).
