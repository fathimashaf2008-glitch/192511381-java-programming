# Q3 – Engineer the hashCode-equals Contract

**Student:** Fathima Shafreena F  |  **Register No.:** 192511381

## Contents
- `src/AttendanceBroken.java`: Executes Complete-the-Code program before overriding `hashCode()` (outputs 3).
- `src/Attendance.java`: Completed program overriding `hashCode()` with `Objects.hash(regNo)` (outputs 2).
- `src/HashContractInvestigation.java`: Three designed contract experiments plus CSV gate scan deduplication.
- `input/gate_scans.csv`: Gate scan sample data.

## Compile and Run
```sh
sh run.sh
```
