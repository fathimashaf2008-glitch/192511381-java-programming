#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out AttendanceBroken | tee output/AttendanceBroken_output.txt
java -cp out Attendance | tee output/Attendance_output.txt
java -cp out HashContractInvestigation | tee output/HashContractInvestigation_output.txt
