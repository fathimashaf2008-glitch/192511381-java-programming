import java.util.HashSet;
import java.util.Set;

class StudentBroken {
    private final String regNo;
    private final String name;

    StudentBroken(String regNo, String name) {
        this.regNo = regNo;
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StudentBroken)) return false;
        return regNo.equals(((StudentBroken) o).regNo);
    }

    // TODO 1 intentionally omitted to record pre-fix behavior

    @Override
    public String toString() {
        return regNo + " - " + name;
    }
}

public class AttendanceBroken {
    public static void main(String[] args) {
        Set<StudentBroken> present = new HashSet<>();
        present.add(new StudentBroken("192311001", "Arun"));   // scanned at Gate 1
        present.add(new StudentBroken("192311002", "Divya"));
        present.add(new StudentBroken("192311001", "Arun"));   // scanned again at Gate 3
        System.out.println("Unique students (WITHOUT hashCode override): " + present.size());
        System.out.println("Set contents: " + present);
    }
}
