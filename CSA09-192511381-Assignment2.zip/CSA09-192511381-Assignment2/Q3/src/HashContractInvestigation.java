import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeSet;

public class HashContractInvestigation {

    static class BrokenStudent {
        String regNo;
        String name;
        BrokenStudent(String regNo, String name) {
            this.regNo = regNo;
            this.name = name;
        }
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof BrokenStudent)) return false;
            return Objects.equals(regNo, ((BrokenStudent) o).regNo);
        }
        @Override
        public String toString() { return regNo + "(" + name + ")"; }
    }

    static class MutableFixedStudent {
        String regNo;
        String name;
        MutableFixedStudent(String regNo, String name) {
            this.regNo = regNo;
            this.name = name;
        }
        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof MutableFixedStudent)) return false;
            return Objects.equals(regNo, ((MutableFixedStudent) o).regNo);
        }
        @Override
        public int hashCode() {
            return Objects.hash(regNo);
        }
        @Override
        public String toString() { return regNo + "(" + name + ")"; }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Q3: Investigation of the hashCode-equals Contract ===\n");

        Set<BrokenStudent> test1 = new HashSet<>();
        BrokenStudent s1 = new BrokenStudent("192511381", "Fathima Shafreena");
        BrokenStudent s2 = new BrokenStudent("192511382", "Kavya");
        test1.add(s1);
        test1.add(s2);
        test1.add(s1);
        System.out.println("Test 1 (Same instance re-scanned on BrokenStudent):");
        System.out.println("  Predicted size: 2 | Observed size: " + test1.size());
        System.out.println("  Contents: " + test1 + "\n");

        Set<BrokenStudent> test2 = new HashSet<>();
        test2.add(new BrokenStudent("192511381", "Fathima Shafreena"));
        test2.add(new BrokenStudent("192511382", "Kavya"));
        test2.add(new BrokenStudent("192511381", "Fathima Shafreena"));
        System.out.println("Test 2 (Distinct instances with equal regNo on BrokenStudent):");
        System.out.println("  Predicted size: 3 (bug exposed) | Observed size: " + test2.size());
        System.out.println("  Contents: " + test2 + "\n");

        Set<MutableFixedStudent> test3 = new HashSet<>();
        MutableFixedStudent m1 = new MutableFixedStudent("192511381", "Fathima");
        test3.add(m1);
        m1.regNo = "192599999";
        boolean foundAfterMutation = test3.contains(m1);
        test3.add(new MutableFixedStudent("192599999", "Fathima"));
        System.out.println("Test 3 (Mutating regNo after HashSet insertion):");
        System.out.println("  Predicted contains(m1) after mutation: false | Observed: " + foundAfterMutation);
        System.out.println("  Predicted size after adding new object with mutated regNo: 2 | Observed: " + test3.size());
        System.out.println("  Contents: " + test3 + "\n");

        Set<Student> fixedSet = new HashSet<>();
        Set<Student> treeSet = new TreeSet<>(Comparator.comparing(st -> st.toString().split(" - ")[0]));
        Map<String, Student> mapByReg = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader("input/gate_scans.csv"))) {
            String line = br.readLine();
            int rawScans = 0;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                String reg = parts[0].trim();
                String nm = parts[1].trim();
                Student st = new Student(reg, nm);
                fixedSet.add(st);
                treeSet.add(st);
                mapByReg.putIfAbsent(reg, st);
                rawScans++;
            }
            System.out.println("--- Verification on input/gate_scans.csv (" + rawScans + " raw scans) ---");
            System.out.println("  HashSet<Student> unique count          : " + fixedSet.size());
            System.out.println("  TreeSet<Student> (Comparator) count    : " + treeSet.size());
            System.out.println("  HashMap<String, Student> unique count  : " + mapByReg.size());
        }
    }
}
