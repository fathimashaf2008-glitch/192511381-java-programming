#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out Triage | tee output/Triage_output.txt
java -cp out TriageAnalysis | tee output/TriageAnalysis_output.txt
