import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Random;

public class TriageAnalysis {

    static class AgedPatient {
        final String name;
        final int baseSeverity;
        final long arrivalTick;
        final long seq;

        AgedPatient(String name, int baseSeverity, long arrivalTick, long seq) {
            this.name = name;
            this.baseSeverity = baseSeverity;
            this.arrivalTick = arrivalTick;
            this.seq = seq;
        }

        int effectiveSeverity(long currentTick) {
            long waited = Math.max(0, currentTick - arrivalTick);
            int promotion = (int) (waited / 15);
            return Math.max(1, baseSeverity - promotion);
        }

        @Override
        public String toString() {
            return name + "(BaseS" + baseSeverity + ",arr=" + arrivalTick + ")";
        }
    }

    static void handVerified8PatientCheck() {
        System.out.println("--- 1. Hand-Verified 8-Patient Correctness & Heap Order Check ---");
        PriorityQueue<Patient> pq = new PriorityQueue<>(
                Comparator.comparingInt((Patient p) -> p.severity)
                          .thenComparingLong(p -> p.arrival)
        );
        String[][] batch = {
            {"P1-Arun", "4"}, {"P2-Divya", "2"}, {"P3-Kiran", "5"}, {"P4-Neha", "1"},
            {"P5-Surya", "2"}, {"P6-Priya", "1"}, {"P7-Vikram", "3"}, {"P8-Anjali", "4"}
        };
        for (int i = 0; i < batch.length; i++) {
            pq.add(new Patient(batch[i][0], Integer.parseInt(batch[i][1]), i));
        }

        System.out.println("  Raw pq.toString() (internal binary heap array order, NOT sorted):");
        System.out.println("    " + pq);

        List<String> served = new ArrayList<>();
        while (!pq.isEmpty()) {
            served.add(pq.poll().toString());
        }
        System.out.println("  Actual poll() treatment order (matches hand trace):");
        System.out.println("    " + served + "\n");
    }

    static void benchmarkQueueGrowth(int n, int runs) {
        Random rng = new Random(42);
        int[] severities = new int[n];
        for (int i = 0; i < n; i++) severities[i] = 1 + rng.nextInt(5);

        long pqAddNs = 0, pqPollNs = 0;
        long bucketAddNs = 0, bucketPollNs = 0;
        long sortedListAddNs = 0, sortedListPollNs = 0;
        int sink = 0;

        for (int r = 0; r < runs; r++) {
            PriorityQueue<Patient> pq = new PriorityQueue<>(
                    Comparator.comparingInt((Patient p) -> p.severity)
                              .thenComparingLong(p -> p.arrival)
            );
            long t0 = System.nanoTime();
            for (int i = 0; i < n; i++) pq.add(new Patient("P" + i, severities[i], i));
            pqAddNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            while (!pq.isEmpty()) sink += pq.poll().severity;
            pqPollNs += System.nanoTime() - t0;

            @SuppressWarnings("unchecked")
            Queue<Patient>[] buckets = new ArrayDeque[6];
            for (int s = 1; s <= 5; s++) buckets[s] = new ArrayDeque<>();

            t0 = System.nanoTime();
            for (int i = 0; i < n; i++) {
                int sev = severities[i];
                buckets[sev].add(new Patient("P" + i, sev, i));
            }
            bucketAddNs += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (int s = 1; s <= 5; s++) {
                while (!buckets[s].isEmpty()) sink += buckets[s].poll().severity;
            }
            bucketPollNs += System.nanoTime() - t0;

            if (n <= 5000) {
                LinkedList<Patient> sortedLL = new LinkedList<>();
                t0 = System.nanoTime();
                for (int i = 0; i < n; i++) {
                    Patient np = new Patient("P" + i, severities[i], i);
                    int idx = 0;
                    for (Patient existing : sortedLL) {
                        if (existing.severity > np.severity) break;
                        idx++;
                    }
                    sortedLL.add(idx, np);
                }
                sortedListAddNs += System.nanoTime() - t0;

                t0 = System.nanoTime();
                while (!sortedLL.isEmpty()) sink += sortedLL.removeFirst().severity;
                sortedListPollNs += System.nanoTime() - t0;
            }
        }
        if (sink == -1) System.out.println(sink);

        System.out.printf("Size N = %6d (avg over %d runs):%n", n, runs);
        System.out.printf("  PriorityQueue   -> admit: %7.3f ms | serve: %7.3f ms%n",
                (pqAddNs / (double) runs) / 1e6, (pqPollNs / (double) runs) / 1e6);
        System.out.printf("  5-Bucket Queues -> admit: %7.3f ms | serve: %7.3f ms%n",
                (bucketAddNs / (double) runs) / 1e6, (bucketPollNs / (double) runs) / 1e6);
        if (n <= 5000) {
            System.out.printf("  Sorted LinkedL  -> admit: %7.3f ms | serve: %7.3f ms%n",
                    (sortedListAddNs / (double) runs) / 1e6, (sortedListPollNs / (double) runs) / 1e6);
        } else {
            System.out.println("  Sorted LinkedL  -> O(n^2) total admit skipped at N=" + n);
        }
    }

    static void demonstrateStarvationAndAging() {
        System.out.println("\n--- 3. Starvation Prevention via Dynamic Aging Rule ---");
        List<AgedPatient> waiting = new ArrayList<>();
        waiting.add(new AgedPatient("Asha-Minor", 5, 0, 1));
        waiting.add(new AgedPatient("Ravi-Mod", 3, 20, 2));
        waiting.add(new AgedPatient("Meena-Urgent", 2, 40, 3));

        long currentTime = 50;
        PriorityQueue<AgedPatient> fairQueue = new PriorityQueue<>(
                Comparator.comparingInt((AgedPatient p) -> p.effectiveSeverity(currentTime))
                          .thenComparingLong(p -> p.arrivalTick)
                          .thenComparingLong(p -> p.seq)
        );
        fairQueue.addAll(waiting);
        System.out.println("  At t=" + currentTime + " mins (15-min aging promotion active):");
        while (!fairQueue.isEmpty()) {
            AgedPatient p = fairQueue.poll();
            System.out.println("    Served: " + p + " -> Effective Severity: S" + p.effectiveSeverity(currentTime));
        }
    }

    static void loadInputPatients(String path) throws Exception {
        PriorityQueue<Patient> pq = new PriorityQueue<>(
                Comparator.comparingInt((Patient p) -> p.severity)
                          .thenComparingLong(p -> p.arrival)
        );
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line = br.readLine();
            long seq = 0;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                pq.add(new Patient(parts[0].trim(), Integer.parseInt(parts[1].trim()), seq++));
            }
        }
        System.out.print("  From input/er_arrivals.csv -> ");
        while (!pq.isEmpty()) System.out.print(pq.poll() + " ");
        System.out.println("\n");
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Q6: Hospital Emergency Triage Analysis ===\n");
        loadInputPatients("input/er_arrivals.csv");
        handVerified8PatientCheck();
        System.out.println("--- 2. Growth Investigation Across Queue Sizes ---");
        benchmarkQueueGrowth(500, 5);
        benchmarkQueueGrowth(5_000, 5);
        benchmarkQueueGrowth(50_000, 5);
        demonstrateStarvationAndAging();
    }
}
