# Q6 – Priority, Order and Fairness in a Queue

**Student:** Fathima Shafreena F  |  **Register No.:** 192511381

## Contents
- `src/Triage.java`: Completed priority triage queue using severity + monotonic arrival counter.
- `src/TriageAnalysis.java`: 8-patient hand-verified trace, binary heap order check, growth benchmarks (500, 5,000, 50,000), and dynamic aging starvation prevention.
- `input/er_arrivals.csv`: Sample emergency department arrival stream.

## Compile and Run
```sh
sh run.sh
```
