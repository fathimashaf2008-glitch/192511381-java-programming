import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

public class PharmacyInventoryBenchmark {

    static class Medicine {
        final String code;
        final String name;
        int stock;

        Medicine(String code, String name, int stock) {
            this.code = code;
            this.name = name;
            this.stock = stock;
        }

        @Override
        public String toString() {
            return code + ":" + name + "(" + stock + ")";
        }
    }

    static boolean isSortedByCode(List<String> codes) {
        for (int i = 1; i < codes.size(); i++) {
            if (codes.get(i - 1).compareTo(codes.get(i)) > 0) return false;
        }
        return true;
    }

    static void benchmarkMapSize(int n, int lookups, int runs) {
        List<Medicine> meds = new ArrayList<>(n);
        Random rng = new Random(192511381L);
        for (int i = 0; i < n; i++) {
            String code = String.format("MED-%06d", rng.nextInt(n * 10));
            meds.add(new Medicine(code, "Drug-" + i, 50 + (i % 200)));
        }
        List<String> insertionOrderExpected = new ArrayList<>();
        Map<String, Medicine> hashMap = new HashMap<>();
        Map<String, Medicine> treeMap = new TreeMap<>();
        Map<String, Medicine> linkedHashMap = new LinkedHashMap<>();

        for (Medicine m : meds) {
            if (!linkedHashMap.containsKey(m.code)) {
                insertionOrderExpected.add(m.code);
            }
            hashMap.put(m.code, m);
            treeMap.put(m.code, m);
            linkedHashMap.put(m.code, m);
        }

        String[] allCodes = linkedHashMap.keySet().toArray(new String[0]);
        String[] queryCodes = new String[lookups];
        for (int i = 0; i < lookups; i++) {
            queryCodes[i] = allCodes[rng.nextInt(allCodes.length)];
        }

        int sink = 0;
        for (int i = 0; i < 1000; i++) {
            String q = queryCodes[i % queryCodes.length];
            sink += hashMap.get(q).stock + treeMap.get(q).stock + linkedHashMap.get(q).stock;
        }

        long hmLookup = 0, tmLookup = 0, lhmLookup = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            for (String q : queryCodes) sink += hashMap.get(q).stock;
            hmLookup += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (String q : queryCodes) sink += treeMap.get(q).stock;
            tmLookup += System.nanoTime() - t0;

            t0 = System.nanoTime();
            for (String q : queryCodes) sink += linkedHashMap.get(q).stock;
            lhmLookup += System.nanoTime() - t0;
        }

        long hmCodeRep = 0, tmCodeRep = 0, lhmCodeRep = 0;
        List<String> hmCodeOut = null, tmCodeOut = null, lhmCodeOut = null;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            hmCodeOut = new ArrayList<>(hashMap.keySet());
            Collections.sort(hmCodeOut);
            for (String k : hmCodeOut) sink += hashMap.get(k).stock;
            hmCodeRep += System.nanoTime() - t0;

            t0 = System.nanoTime();
            tmCodeOut = new ArrayList<>(treeMap.keySet());
            for (Map.Entry<String, Medicine> e : treeMap.entrySet()) sink += e.getValue().stock;
            tmCodeRep += System.nanoTime() - t0;

            t0 = System.nanoTime();
            lhmCodeOut = new ArrayList<>(linkedHashMap.keySet());
            Collections.sort(lhmCodeOut);
            for (String k : lhmCodeOut) sink += linkedHashMap.get(k).stock;
            lhmCodeRep += System.nanoTime() - t0;
        }

        long lhmInsRep = 0;
        List<String> lhmInsOut = null;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            lhmInsOut = new ArrayList<>(linkedHashMap.keySet());
            for (Map.Entry<String, Medicine> e : linkedHashMap.entrySet()) sink += e.getValue().stock;
            lhmInsRep += System.nanoTime() - t0;
        }

        Medicine[] sortedArr = linkedHashMap.values().toArray(new Medicine[0]);
        Arrays.sort(sortedArr, (a, b) -> a.code.compareTo(b.code));
        String[] sortedKeys = new String[sortedArr.length];
        for (int i = 0; i < sortedArr.length; i++) sortedKeys[i] = sortedArr[i].code;
        long arrLookup = 0;
        for (int r = 0; r < runs; r++) {
            long t0 = System.nanoTime();
            for (String q : queryCodes) {
                int idx = Arrays.binarySearch(sortedKeys, q);
                if (idx >= 0) sink += sortedArr[idx].stock;
            }
            arrLookup += System.nanoTime() - t0;
        }
        if (sink == -1) System.out.println(sink);

        System.out.printf("=== Pharmacy Inventory Size N = %d unique medicines (avg over %d runs) ===%n",
                allCodes.length, runs);
        System.out.printf("  100,000 Lookups  -> HashMap: %6.3f ms | LinkedHashMap: %6.3f ms | TreeMap: %6.3f ms | SortedArray: %6.3f ms%n",
                (hmLookup / (double) runs) / 1e6,
                (lhmLookup / (double) runs) / 1e6,
                (tmLookup / (double) runs) / 1e6,
                (arrLookup / (double) runs) / 1e6);
        System.out.printf("  Code-Order Rep   -> TreeMap (native): %6.3f ms | HashMap (+sort): %6.3f ms | LinkedHashMap (+sort): %6.3f ms%n",
                (tmCodeRep / (double) runs) / 1e6,
                (hmCodeRep / (double) runs) / 1e6,
                (lhmCodeRep / (double) runs) / 1e6);
        System.out.printf("  Insert-Order Rep -> LinkedHashMap (native): %6.3f ms | HashMap/TreeMap: Requires extra insertion log%n",
                (lhmInsRep / (double) runs) / 1e6);
        System.out.printf("  Order Matches?   -> TreeMap CodeSorted=%b | LinkedHashMap InsertOrder=%b | HashMap NativeCodeSorted=%b%n%n",
                isSortedByCode(tmCodeOut),
                lhmInsOut.equals(insertionOrderExpected),
                isSortedByCode(new ArrayList<>(hashMap.keySet())));
    }

    static void verifySampleFile(String path) throws Exception {
        Map<String, Medicine> lhm = new LinkedHashMap<>();
        Map<String, Medicine> tm = new TreeMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line = br.readLine();
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] p = line.split(",");
                Medicine m = new Medicine(p[0].trim(), p[1].trim(), Integer.parseInt(p[2].trim()));
                lhm.put(m.code, m);
                tm.put(m.code, m);
            }
        }
        System.out.println("--- Sample Pharmacy Stock (input/medicines.csv) ---");
        System.out.println("  Insertion Order (LinkedHashMap): " + lhm.values());
        System.out.println("  Code Order      (TreeMap)      : " + tm.values() + "\n");
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Q4: Hospital Pharmacy Stock Lookup Benchmark ===\n");
        verifySampleFile("input/medicines.csv");
        benchmarkMapSize(500, 100_000, 5);
        benchmarkMapSize(5_000, 100_000, 5);
        benchmarkMapSize(50_000, 100_000, 3);
    }
}
