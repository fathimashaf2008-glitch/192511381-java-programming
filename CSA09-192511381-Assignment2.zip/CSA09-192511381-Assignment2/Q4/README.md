# Q4 – Choosing a Map for a Pharmacy Inventory

**Student:** Fathima Shafreena F  |  **Register No.:** 192511381

## Contents
- `src/PharmacyInventoryBenchmark.java`: Evaluates `HashMap`, `LinkedHashMap`, `TreeMap`, and sorted array binary search across three inventory sizes.
- `input/medicines.csv`: Sample medicine inventory records.

## Compile and Run
```sh
sh run.sh
```

## Result Summary
`LinkedHashMap` delivers ~42 ns per lookup (4.18 ms for 100k lookups at N=47,561) while preserving insertion order natively in O(N) and generating the evening code-order report via a single O(N log N) sort (~26 ms once per day).
