#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out PharmacyInventoryBenchmark | tee output/PharmacyInventoryBenchmark_output.txt
