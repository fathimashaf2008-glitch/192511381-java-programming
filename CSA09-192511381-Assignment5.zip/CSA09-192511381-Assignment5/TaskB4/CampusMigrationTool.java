import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CampusMigrationTool {
    private static final String URL = "jdbc:mysql://localhost:3306/transport_db?rewriteBatchedStatements=true";
    private static final String USER = "root";
    private static final String PWD = "password";

    public static void inspectDatabase(Connection con) throws SQLException {
        DatabaseMetaData meta = con.getMetaData();
        System.out.println("=== DatabaseMetaData Inspection ===");
        System.out.println("Database Product : " + meta.getDatabaseProductName() + " " + meta.getDatabaseProductVersion());
        System.out.println("JDBC Driver      : " + meta.getDriverName() + " " + meta.getDriverVersion());
        System.out.print("Tables Present   : ");
        try (ResultSet tables = meta.getTables("transport_db", null, "%", new String[]{"TABLE"})) {
            List<String> names = new ArrayList<>();
            while (tables.next()) {
                names.add(tables.getString("TABLE_NAME"));
            }
            System.out.println(names);
        }
    }

    public static void migrateFile(Connection con, Path csvFile) throws IOException, SQLException {
        List<String> rejectedLines = new ArrayList<>();
        String sql = "INSERT INTO bus_pass (pass_id, reg_no, name, route_no, amount) VALUES (?, ?, ?, ?, ?)";

        con.setAutoCommit(false);
        try (BufferedReader reader = Files.newBufferedReader(csvFile);
             PreparedStatement ps = con.prepareStatement(sql)) {

            String line;
            int lineNum = 0;
            int validCount = 0;

            while ((line = reader.readLine()) != null) {
                lineNum++;
                if (line.trim().isEmpty()) {
                    continue;
                }
                String[] parts = line.split(",", -1);
                if (parts.length != 5) {
                    rejectedLines.add("Line " + lineNum + " [Invalid column count]: " + line);
                    continue;
                }
                try {
                    String passId = parts[0].trim();
                    String regNo = parts[1].trim();
                    String name = parts[2].trim();
                    int route = Integer.parseInt(parts[3].trim());
                    double amount = Double.parseDouble(parts[4].trim());

                    if (passId.isEmpty() || regNo.isEmpty() || amount <= 0) {
                        throw new IllegalArgumentException("Empty ID or non-positive amount");
                    }

                    ps.setString(1, passId);
                    ps.setString(2, regNo);
                    ps.setString(3, name);
                    ps.setInt(4, route);
                    ps.setDouble(5, amount);
                    ps.addBatch();
                    validCount++;

                    if (validCount % 1000 == 0) {
                        ps.executeBatch();
                    }
                } catch (Exception ex) {
                    rejectedLines.add("Line " + lineNum + " [" + ex.getMessage() + "]: " + line);
                }
            }

            ps.executeBatch();
            con.commit();

            System.out.println("=== Migration Summary ===");
            System.out.println("Successfully migrated rows : " + validCount);
            System.out.println("Rejected invalid rows      : " + rejectedLines.size());
            for (String err : rejectedLines) {
                System.out.println("  -> " + err);
            }
        } catch (SQLException e) {
            con.rollback();
            throw e;
        } finally {
            con.setAutoCommit(true);
        }
    }

    public static void main(String[] args) throws Exception {
        Path sampleCsv = Files.createTempFile("campus_passes", ".csv");
        String sampleData = String.join("
",
                "P5001,192511381,Fathima Shafreena,12,4500.00",
                "P5002,192511382,Karthik,8,3800.00",
                "P5003,BAD_RECORD",
                "P5004,192511384,Meena,5,-250.00",
                "P5005,192511385,Anand,3,4100.00"
        ) + "
";
        Files.writeString(sampleCsv, sampleData, StandardOpenOption.WRITE);

        try (Connection con = DriverManager.getConnection(URL, USER, PWD)) {
            inspectDatabase(con);
            migrateFile(con, sampleCsv);
        } finally {
            Files.delete(sampleCsv);
        }
    }
}
