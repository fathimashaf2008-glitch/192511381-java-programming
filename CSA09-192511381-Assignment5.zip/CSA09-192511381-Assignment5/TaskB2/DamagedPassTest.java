import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;

public class DamagedPassTest {
    public static void main(String[] args) throws IOException {
        Path adversarialFile = Files.createTempFile("adversarial_passes", ".csv");
        String content = String.join("
",
                "P2001,192511381,Fathima Shafreena,14,4500.0",
                "",                                                // Empty line
                "P2002,192511382,CORRUPTED_MISSING_FIELDS",        // Wrong field count
                "P2003,192511383,Rahul,10,NOT_A_NUMBER",           // Non-numeric amount
                "P2004,192511384,Sneha,14,4200.0"
        ) + "
";

        Files.writeString(adversarialFile, content, StandardOpenOption.WRITE);

        // Reuse PassStore logic
        PassStore store = new PassStore(adversarialFile);
        System.out.println("Search P2001 (Valid)          : " + Arrays.toString(store.find("P2001")));
        System.out.println("Search P2002 (Missing Fields) : " + Arrays.toString(store.find("P2002")));
        System.out.println("Search P2003 (Bad Amount)     : " + Arrays.toString(store.find("P2003")));
        System.out.println("Search P2004 (After Damaged)  : " + Arrays.toString(store.find("P2004")));
        System.out.println("List Route 14 count           : " + store.listByRoute(14).size());

        Files.delete(adversarialFile);
    }
}
