import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class JdbcBenchmark {
    private static final String URL = "jdbc:mysql://localhost:3306/transport_db?rewriteBatchedStatements=true";
    private static final String USER = "root";
    private static final String PWD = "password";

    private static List<String[]> generatePasses(int count) {
        List<String[]> list = new ArrayList<>(count);
        for (int i = 1; i <= count; i++) {
            list.add(new String[]{
                    String.format("P%06d", i),
                    "1925" + String.format("%05d", i),
                    "Student_" + i,
                    String.valueOf((i % 25) + 1),
                    "4500.00"
            });
        }
        return list;
    }

    private static void truncateTable(Connection con) throws SQLException {
        try (Statement st = con.createStatement()) {
            st.executeUpdate("TRUNCATE TABLE bus_pass");
        }
    }

    private static int countRows(Connection con) throws SQLException {
        try (Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT COUNT(*) FROM bus_pass")) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    public static void main(String[] args) {
        try (Connection con = DriverManager.getConnection(URL, USER, PWD)) {
            // B3.1: Verify 10 rows and ResultSetMetaData
            truncateTable(con);
            PassLoader.loadAll(con, generatePasses(10));
            try (Statement st = con.createStatement();
                 ResultSet rs = st.executeQuery("SELECT * FROM bus_pass LIMIT 5")) {
                ResultSetMetaData meta = rs.getMetaData();
                System.out.println("=== B3.1 ResultSetMetaData ===");
                for (int c = 1; c <= meta.getColumnCount(); c++) {
                    System.out.printf("Col %d: %s (%s)%n", c, meta.getColumnName(c), meta.getColumnTypeName(c));
                }
            }

            // B3.2: Benchmark 1,000, 10,000, 100,000
            System.out.println("
=== B3.2 Insert Benchmark ===");
            int[] sizes = {1_000, 10_000, 100_000};
            for (int size : sizes) {
                List<String[]> data = generatePasses(size);

                // (a) Statement
                truncateTable(con);
                long t1 = System.nanoTime();
                try (Statement st = con.createStatement()) {
                    for (String[] p : data) {
                        st.executeUpdate("INSERT INTO bus_pass VALUES ('" + p[0] + "','" + p[1] + "','" + p[2] + "'," + p[3] + "," + p[4] + ")");
                    }
                }
                long stmtMs = (System.nanoTime() - t1) / 1_000_000;

                // (b) PreparedStatement
                truncateTable(con);
                long t2 = System.nanoTime();
                try (PreparedStatement ps = con.prepareStatement("INSERT INTO bus_pass VALUES (?, ?, ?, ?, ?)")) {
                    for (String[] p : data) {
                        ps.setString(1, p[0]);
                        ps.setString(2, p[1]);
                        ps.setString(3, p[2]);
                        ps.setInt(4, Integer.parseInt(p[3]));
                        ps.setDouble(5, Double.parseDouble(p[4]));
                        ps.executeUpdate();
                    }
                }
                long prepMs = (System.nanoTime() - t2) / 1_000_000;

                // (c) Transactional Batch
                truncateTable(con);
                long t3 = System.nanoTime();
                PassLoader.loadAll(con, data);
                long batchMs = (System.nanoTime() - t3) / 1_000_000;

                System.out.printf("N=%-7d | Statement: %6d ms | Prepared: %6d ms | Batch+Tx: %5d ms%n",
                        size, stmtMs, prepMs, batchMs);
            }

            // B3.3: Mid-batch failure rollback test
            System.out.println("
=== B3.3 Transaction Rollback Test ===");
            truncateTable(con);
            List<String[]> corruptBatch = generatePasses(2000);
            corruptBatch.get(1000)[4] = "INVALID_AMOUNT"; // Causes NumberFormatException mid-way
            try {
                PassLoader.loadAll(con, corruptBatch);
            } catch (Exception ex) {
                System.out.println("Caught expected failure: " + ex);
            }
            System.out.println("Rows remaining in table after rollback: " + countRows(con));

        } catch (SQLException e) {
            System.err.println("DB Error: " + e.getMessage());
        }
    }
}
