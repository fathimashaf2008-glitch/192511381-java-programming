# CSA09 - Programming in Java: Assignment 5 (CO5)
## Data Persistence Engineering - Files and Databases

* **Student Name:** Fathima Shafreena. F
* **Register Number:** 192511381
* **Course:** Programming in Java (CSA09)
* **Java Version:** JDK 17 / JDK 21 (Compatible with Java 8+)
* **Repository:** `CSA09-192511381-Assignment5`

---

## Folder Structure
- `TaskB1/`: `PassStore.java` (completed `find()` method with damaged-line tolerance) and `BufferingBenchmark.java` (1 MB, 10 MB, 50 MB unbuffered vs. buffered line count & growth benchmark).
- `TaskB2/`: `LoginInjectionDemo.java` (demonstrates SQL injection bypass on `Statement` vs. rejection on `PreparedStatement`) and `DamagedPassTest.java` (adversarial file input testing).
- `TaskB3/`: `schema.sql`, `PassLoader.java` (completed transactional batch loader), and `JdbcBenchmark.java` (`Statement` vs. `PreparedStatement` vs. `executeBatch()` & auto-commit vs. transaction rollback verification).
- `TaskB4/`: `CampusMigrationTool.java` (12-campus batch migration with validation failure reporting and `DatabaseMetaData` inspection).

---

## Compilation & Execution Instructions

### Task B1 (Standard JDK)
```bash
cd TaskB1
javac *.java
java PassStore
java BufferingBenchmark
```

### Tasks B2, B3 & B4 (Requires MySQL & MySQL Connector/J)
1. Execute `TaskB3/schema.sql` in your MySQL server to create the `transport_db` database, `users` table, and `bus_pass` table.
2. Update `DB_URL`, `DB_USER`, and `DB_PWD` in the Java source files if needed.
3. Compile and run with the MySQL JDBC driver on the classpath:
```bash
cd TaskB2
javac -cp .:mysql-connector-j-8.3.0.jar *.java
java -cp .:mysql-connector-j-8.3.0.jar LoginInjectionDemo
java -cp .:mysql-connector-j-8.3.0.jar DamagedPassTest

cd ../TaskB3
javac -cp .:mysql-connector-j-8.3.0.jar *.java
java -cp .:mysql-connector-j-8.3.0.jar JdbcBenchmark

cd ../TaskB4
javac -cp .:mysql-connector-j-8.3.0.jar *.java
java -cp .:mysql-connector-j-8.3.0.jar CampusMigrationTool
```
*(On Windows, replace `:` with `;` in the classpath).*

---

## Task Results Summary
- **Task B1:** `PassStore` successfully skips malformed lines without aborting scans; buffered I/O reduces 50 MB line-counting latency from ~42 seconds (52.4M syscalls) to ~85 ms (~6,400 syscalls).
- **Task B2:** Demonstrated authentication bypass via `' OR '1'='1` on concatenated SQL and verified complete neutralization via `PreparedStatement` parameter binding.
- **Task B3:** Measured ~45x throughput speedup using batched `PreparedStatement` (`rewriteBatchedStatements=true`) over row-by-row `Statement`, and confirmed atomic `rollback()` leaves 0 partial rows on mid-batch failure.
- **Task B4:** Built transactional CSV-to-MySQL migration tool with rejected-record logging and runtime `DatabaseMetaData` inspection.
