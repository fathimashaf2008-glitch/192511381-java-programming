import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class BufferingBenchmark {
    private static void generateLogFile(Path path, int targetBytes) throws IOException {
        byte[] sampleLine = "2026-11-19 08:30:15 | REG=192511381 | ROUTE=12 | STATUS=BOARDED\n"
                .getBytes(StandardCharsets.UTF_8);
        int written = 0;
        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(path.toFile()))) {
            while (written < targetBytes) {
                out.write(sampleLine);
                written += sampleLine.length;
            }
        }
    }

    private static long countLinesUnbuffered(Path path) throws IOException {
        long lines = 0;
        try (InputStream in = new FileInputStream(path.toFile())) {
            int b;
            while ((b = in.read()) != -1) {
                if (b == '\n') {
                    lines++;
                }
            }
        }
        return lines;
    }

    private static long countLinesBuffered(Path path) throws IOException {
        long lines = 0;
        try (InputStream in = new BufferedInputStream(new FileInputStream(path.toFile()), 8192)) {
            int b;
            while ((b = in.read()) != -1) {
                if (b == '\n') {
                    lines++;
                }
            }
        }
        return lines;
    }

    public static void main(String[] args) throws IOException {
        int[] sizesMb = {1, 10, 50};
        System.out.printf("%-10s | %-18s | %-18s | %-12s%n", "File Size", "Unbuffered (ms)", "Buffered 8KB (ms)", "Line Count");
        System.out.println("-------------------------------------------------------------------");

        for (int mb : sizesMb) {
            Path tempLog = Files.createTempFile("attendance_" + mb + "mb", ".log");
            generateLogFile(tempLog, mb * 1024 * 1024);

            long t1 = System.nanoTime();
            long linesUnbuf = countLinesUnbuffered(tempLog);
            long unbufMs = (System.nanoTime() - t1) / 1_000_000;

            long t2 = System.nanoTime();
            long linesBuf = countLinesBuffered(tempLog);
            long bufMs = (System.nanoTime() - t2) / 1_000_000;

            System.out.printf("%-10s | %-18d | %-18d | %-12d%n", mb + " MB", unbufMs, bufMs, linesBuf);
            if (linesUnbuf != linesBuf) {
                throw new IllegalStateException("Line count mismatch!");
            }
            Files.delete(tempLog);
        }

        // Growth benchmark for PassStore.find()
        System.out.println("\n--- PassStore Linear Scan Growth Benchmark ---");
        int[] recordCounts = {1_000, 10_000, 100_000};
        for (int n : recordCounts) {
            Path passFile = Files.createTempFile("growth_" + n, ".csv");
            PassStore store = new PassStore(passFile);
            try (BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(passFile.toFile()))) {
                for (int i = 1; i <= n; i++) {
                    String row = "P" + i + ",1925" + i + ",Student" + i + ",12,4500.0\n";
                    bos.write(row.getBytes(StandardCharsets.UTF_8));
                }
            }
            long start = System.nanoTime();
            String[] found = store.find("P" + n); // Worst-case last record
            double elapsedMs = (System.nanoTime() - start) / 1_000_000.0;
            System.out.printf("Records: %-8d | Worst-case find() time: %.3f ms | Found: %s%n",
                    n, elapsedMs, found != null ? found[0] : "null");
            Files.delete(passFile);
        }
    }
}
