import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.locks.ReentrantLock;

public class CinemaSyncBenchmark {

    static class UnsynchronizedScreen {
        final boolean[] booked;
        int bookingsMade = 0;
        UnsynchronizedScreen(int seats) { booked = new boolean[seats]; }

        void book(int seat) {
            if (!booked[seat]) {
                Thread.yield();
                booked[seat] = true;
                bookingsMade++;
            }
        }
    }

    static class SyncMethodScreen {
        final boolean[] booked;
        int bookingsMade = 0;
        SyncMethodScreen(int seats) { booked = new boolean[seats]; }

        synchronized boolean book(int seat) {
            if (!booked[seat]) {
                booked[seat] = true;
                bookingsMade++;
                return true;
            }
            return false;
        }
    }

    static class SyncBlockScreen {
        final boolean[] booked;
        int bookingsMade = 0;
        private final Object lock = new Object();
        SyncBlockScreen(int seats) { booked = new boolean[seats]; }

        boolean book(int seat) {
            if (seat < 0 || seat >= booked.length) return false;
            synchronized (lock) {
                if (!booked[seat]) {
                    booked[seat] = true;
                    bookingsMade++;
                    return true;
                }
                return false;
            }
        }
    }

    static class AtomicCasScreen {
        final AtomicBoolean[] booked;
        final AtomicInteger bookingsMade = new AtomicInteger(0);
        AtomicCasScreen(int seats) {
            booked = new AtomicBoolean[seats];
            for (int i = 0; i < seats; i++) booked[i] = new AtomicBoolean(false);
        }

        boolean book(int seat) {
            if (booked[seat].compareAndSet(false, true)) {
                bookingsMade.incrementAndGet();
                return true;
            }
            return false;
        }
    }

    static class ReentrantLockScreen {
        final boolean[] booked;
        int bookingsMade = 0;
        private final ReentrantLock lock = new ReentrantLock();
        ReentrantLockScreen(int seats) { booked = new boolean[seats]; }

        boolean book(int seat) {
            lock.lock();
            try {
                if (!booked[seat]) {
                    booked[seat] = true;
                    bookingsMade++;
                    return true;
                }
                return false;
            } finally {
                lock.unlock();
            }
        }
    }

    static class ConcurrentMapScreen {
        final ConcurrentHashMap<Integer, Boolean> booked = new ConcurrentHashMap<>();
        final AtomicInteger bookingsMade = new AtomicInteger(0);

        boolean book(int seat) {
            if (booked.putIfAbsent(seat, Boolean.TRUE) == null) {
                bookingsMade.incrementAndGet();
                return true;
            }
            return false;
        }
    }

    static void reproduceRace10Runs() throws InterruptedException {
        System.out.println("--- 1. Reproducing Race Condition (10 runs x 100 threads competing for 10 seats) ---");
        for (int run = 1; run <= 10; run++) {
            UnsynchronizedScreen screen = new UnsynchronizedScreen(10);
            CountDownLatch gate = new CountDownLatch(1);
            Thread[] threads = new Thread[100];
            for (int i = 0; i < 100; i++) {
                final int seat = i % 10;
                threads[i] = new Thread(() -> {
                    try { gate.await(); } catch (InterruptedException ignored) {}
                    screen.book(seat);
                });
                threads[i].start();
            }
            gate.countDown();
            for (Thread t : threads) t.join();
            System.out.printf("  Run %2d (Unsynchronized) -> Seats sold: %2d (Expected: 10, Double bookings: %d)%n",
                    run, screen.bookingsMade, Math.max(0, screen.bookingsMade - 10));
        }
        System.out.println();
    }

    static void benchmarkStrategies(int totalBookings, int numSeats, int numThreads) throws InterruptedException {
        System.out.printf("--- 2. Throughput Comparison (%d booking attempts, %d seats, %d threads) ---%n",
                totalBookings, numSeats, numThreads);

        for (int w = 0; w < 2; w++) {
            SyncMethodScreen sm = new SyncMethodScreen(numSeats);
            for (int i = 0; i < 1000; i++) sm.book(i % numSeats);
        }

        SyncMethodScreen syncMethod = new SyncMethodScreen(numSeats);
        long t0 = System.nanoTime();
        runPoolBookings(totalBookings, numSeats, numThreads, syncMethod::book);
        double syncMethodMs = (System.nanoTime() - t0) / 1e6;

        SyncBlockScreen syncBlock = new SyncBlockScreen(numSeats);
        t0 = System.nanoTime();
        runPoolBookings(totalBookings, numSeats, numThreads, syncBlock::book);
        double syncBlockMs = (System.nanoTime() - t0) / 1e6;

        AtomicCasScreen atomicScreen = new AtomicCasScreen(numSeats);
        t0 = System.nanoTime();
        runPoolBookings(totalBookings, numSeats, numThreads, atomicScreen::book);
        double atomicMs = (System.nanoTime() - t0) / 1e6;

        ReentrantLockScreen reentrantScreen = new ReentrantLockScreen(numSeats);
        t0 = System.nanoTime();
        runPoolBookings(totalBookings, numSeats, numThreads, reentrantScreen::book);
        double reentrantMs = (System.nanoTime() - t0) / 1e6;

        ConcurrentMapScreen cmapScreen = new ConcurrentMapScreen();
        t0 = System.nanoTime();
        runPoolBookings(totalBookings, numSeats, numThreads, cmapScreen::book);
        double cmapMs = (System.nanoTime() - t0) / 1e6;

        System.out.printf("  Synchronized Method       : %7.3f ms | Seats Sold: %d%n", syncMethodMs, syncMethod.bookingsMade);
        System.out.printf("  Synchronized Block        : %7.3f ms | Seats Sold: %d%n", syncBlockMs, syncBlock.bookingsMade);
        System.out.printf("  AtomicBoolean[] (CAS)     : %7.3f ms | Seats Sold: %d%n", atomicMs, atomicScreen.bookingsMade.get());
        System.out.printf("  ReentrantLock             : %7.3f ms | Seats Sold: %d%n", reentrantMs, reentrantScreen.bookingsMade);
        System.out.printf("  ConcurrentHashMap         : %7.3f ms | Seats Sold: %d%n", cmapMs, cmapScreen.bookingsMade.get());
    }

    interface Booker { boolean book(int seat); }

    static void runPoolBookings(int totalBookings, int numSeats, int numThreads, Booker booker) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(numThreads);
        int perThread = totalBookings / numThreads;
        for (int t = 0; t < numThreads; t++) {
            final int offset = t;
            pool.submit(() -> {
                for (int i = 0; i < perThread; i++) {
                    booker.book((i + offset) % numSeats);
                }
            });
        }
        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.SECONDS);
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Q5: Cinema Seat-Booking Race Condition & Synchronization Analysis ===\n");
        reproduceRace10Runs();
        benchmarkStrategies(10_000, 200, 8);
    }
}
