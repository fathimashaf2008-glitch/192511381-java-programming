#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out SeatBooking | tee output/SeatBooking_output.txt
java -cp out CinemaSyncBenchmark | tee output/CinemaSyncBenchmark_output.txt
