# Q5 – Race Conditions in a Cinema Seat-Booking System

* `src/SeatBooking.java`: Completed `TODO 1` (`Seats sold: 10`).
* `src/CinemaSyncBenchmark.java`: 10-run race reproduction plus 10,000-booking benchmark comparing `synchronized` method, `synchronized` block, `AtomicBoolean[]` CAS, `ReentrantLock`, and `ConcurrentHashMap`.

## Run
```sh
sh run.sh
```
