# CSA09-192525472-Assignment3

**CO3 Analysis & Design Evaluation: Exception Handling & Multithreading (Sessions 27–38)**

* **Student A (Register No. 192525472):** Primary Repository Owner | CSA09 – Programming in Java (CO3)
* **Student B (Pair Partner):** Co-Contributor (Alternating Responsibilities across Q1–Q7)
* **GitHub Repository:** https://github.com/student192525472/CSA09-192525472-Assignment3
* **Java Version:** Compiled and run with Java 21.0.12.1

## Folder Layout

Each task follows the standard repository submission layout:

```
Q1/ .. Q7/
  src/       Java source code (including completed 'Complete the Code' programs)
  input/     Input datasets used during execution
  output/    Program console logs (*_output.txt) and terminal screenshots (*_console.png)
  README.md  Task overview, compile/run steps, and result summary
  run.sh     Compile and run script
```

| Folder | Question / Topic | Main Source Files |
|---|---|---|
| [Q1](Q1/) | Handling Failure in a Bank ATM Simulation | `ATMWithdrawalSimulation.java` |
| [Q2](Q2/) | User-Defined Exceptions and Propagation in an Online Examination Portal | `StorageDemo.java`, `ExamPortalPropagationDemo.java` |
| [Q3](Q3/) | Resource Safety, Debugging and Robust Code | `DailySalesReportGenerator.java` |
| [Q4](Q4/) | Thread Creation and the Thread Life Cycle | `AnswerScriptScannerDemo.java` |
| [Q5](Q5/) | Race Conditions in a Cinema Seat-Booking System | `SeatBooking.java`, `CinemaSyncBenchmark.java` |
| [Q6](Q6/) | Deadlock and Inter-Thread Communication | `TokenCounter.java`, `HostelDeadlockAndCounterDemo.java` |
| [Q7](Q7/) | Design a Concurrent, Fault-Tolerant Processor from First Principles | `SemesterResultProcessor.java` |

## Complete Joint Report

See [`ASSIGNMENT3_REPORT.md`](ASSIGNMENT3_REPORT.md) for the full CO3 pair-work report containing Student A & Student B labelled sections, Individual Contribution Record, diagrams, test tables, stack traces, and Big-O complexity analyses.

## Quick Run

```sh
cd Q1
sh run.sh
```
