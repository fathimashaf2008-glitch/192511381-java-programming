# CSA09 – PROGRAMMING IN JAVA
## ASSIGNMENT 3 – CO3 JOINT REPORT

* **Course:** CSA09 – Programming in Java (CO3: Exception Handling & Multithreading)
* **Student A (Name & Register No.):** Student A (Register No: `192525472`)
* **Student B (Name & Register No.):** Student B (Pair Partner)
* **GitHub Repository Link (Student A):** https://github.com/student192525472/CSA09-192525472-Assignment3
* **GitHub Repository Link (Student B):** https://github.com/studentB-partner/CSA09-Partner-Assignment3
* **Java Version:** Java 21.0.12.1

---

## Individual Contribution Record

| Question | Student A – Primary Responsibility | Student B – Primary Responsibility | Joint |
|---|---|---|---|
| **Q1** | Exception hierarchy diagram, failure-point table, catch-block order justification, `finally` guarantee analysis | 6-path test design & execution log, uncaught stack trace line-by-line breakdown, catch-order compiler error demo | Single `catch (Exception e)` evaluation & error-code vs exception analysis |
| **Q2** | Custom exception class hierarchy diagram, checked vs unchecked justification, 3-layer propagation path & UI message design | Scenario construction for every exception, `getCause()` chained stack trace vs lost-cause comparison, test table | Storage-to-UI encapsulation rationale, `StorageDemo` `TODO 1`, unchecked alternative analysis |
| **Q3** | Breakpoint debugging of manual file-handle leak, failing input construction, open-handle count comparison & failure logging | Resource inventory & close points, exception leak analysis, TWR LIFO closing guarantee & suppressed exceptions | Conditions where TWR alone is insufficient & $O(f)$ file-handle complexity analysis |
| **Q4** | `extends Thread` vs `implements Runnable` design, 6-state Thread life-cycle diagram, direct `run()` evidence, `join()` guarantee | 10-run finish-order experiments, priority experiments, daemon thread termination experiment & scheduler analysis | Non-deterministic output order conclusion & `ExecutorService` thread-stack complexity |
| **Q5** | Reliable double-booking race test, 10-run double-booking log, step-by-step thread interleaving & critical section identification | 10,000-booking throughput benchmark across strategies, method vs block lock comparison, static & intrinsic lock analysis | 20-screen cinema deployment decision, `SeatBooking` `TODO 1`, CAS/Lock/Map analysis |
| **Q6** | `wait()` loop & monitor rules, `notify()` vs `notifyAll()` analysis, bounded counter (`0..5`) trace, `sleep()` vs `wait()` comparison | Reproducible wallet transfer deadlock, 4 Coffman deadlock conditions, lexicographical lock-ordering prevention proof | Progress guarantees across deadlock & producer-consumer, `TokenCounter` `TODO 1 & 2` |
| **Q7** | Stage 2: `ExecutorService`/`Callable`/`Future` architecture, `ConcurrentHashMap` justification, fault isolation & class diagram | Stage 3: Implementation with missing/corrupt file injection, 1/2/4/8 thread pool benchmarks & hand-checked verification | Stage 1 problem decomposition, Stage 4 optimal pool-size defense & `parallelStream()` comparison |

---

## Q1 – Handling Failure in a Bank ATM Simulation (6 Marks — K4: Analyse)

### Shared Group Work
All failure points during an ATM withdrawal were identified, classified across Java's `Throwable` hierarchy, implemented in `Q1/src/ATMWithdrawalSimulation.java` using `try`, multi-catch (`NumberFormatException | InvalidAmountException`), and `finally`, and tested across 6 distinct execution paths.

### Student A – Exception Design
1. **Relevant `Throwable` Hierarchy:**
   ```text
   java.lang.Object
    └── java.lang.Throwable
         ├── java.lang.Error (Unchecked — e.g., OutOfMemoryError, VirtualMachineError; not caught)
         └── java.lang.Exception
              ├── java.io.IOException (Checked)
              │    └── java.io.FileNotFoundException (Checked — missing card-reader file)
              ├── InsufficientFundsException (Checked — custom business rule)
              └── java.lang.RuntimeException (Unchecked)
                   └── java.lang.IllegalArgumentException (Unchecked — unknown account)
                        ├── java.lang.NumberFormatException (Unchecked — non-numeric input)
                        └── InvalidAmountException (Unchecked — negative/zero amount)
   ```

2. **Failure Point Classification Table:**

| Failure Point | Exception Type | Checked / Unchecked | Where It Is Caught |
|---|---|---|---|
| Card-reader database file missing on disk | `FileNotFoundException` | Checked | `catch (FileNotFoundException e)` in `processWithdrawal` |
| Disk read failure while reading card file | `IOException` | Checked | `catch (IOException e)` in `processWithdrawal` |
| User types letters instead of numeric amount | `NumberFormatException` | Unchecked | Multi-catch `catch (NumberFormatException \| InvalidAmountException e)` |
| User enters negative or zero withdrawal amount | `InvalidAmountException` | Unchecked | Multi-catch `catch (NumberFormatException \| InvalidAmountException e)` |
| Withdrawal amount exceeds available balance | `InsufficientFundsException` | Checked | `catch (InsufficientFundsException e)` in `processWithdrawal` |
| Account number not found in card-reader map | `IllegalArgumentException` | Unchecked | `catch (IllegalArgumentException e)` in `processWithdrawal` |

3. **Justification of `catch` Block Order:**
   * `FileNotFoundException` is a subclass of `IOException`, so it **must** appear before `IOException`; otherwise `IOException` would shadow it.
   * `NumberFormatException` and `InvalidAmountException` are both subclasses of `IllegalArgumentException`, so their multi-catch block **must** precede the broader `catch (IllegalArgumentException e)` handler used for unknown account numbers.
4. **What `finally` Guarantees:**
   * Regardless of whether withdrawal succeeds, throws a checked/unchecked exception, or returns early, the `finally` block **always executes** (unless the JVM terminates via `System.exit()` or power loss), guaranteeing that the ATM card is ejected, keypad buffers are cleared, and `sessionActive` is reset to `false`.

### Student B – Testing and Tracing
1. **Test Execution Table (6 Paths):**

| Test # | Input (`file`, `acc`, `amount`) | Triggered Path / Catch Block | `finally` Executed? |
|---|---|---|---|
| **T1** | `accounts.csv`, `ACC1001`, `2500` | None (Success: dispensed ₹2,500; balance ₹12,500) | **Yes** |
| **T2** | `accounts.csv`, `ACC1001`, `fifty` | Multi-catch (`NumberFormatException`) | **Yes** |
| **T3** | `accounts.csv`, `ACC1001`, `-500` | Multi-catch (`InvalidAmountException`) | **Yes** |
| **T4** | `accounts.csv`, `ACC1001`, `95000` | `catch (InsufficientFundsException e)` | **Yes** |
| **T5** | `missing_card.csv`, `ACC1001`, `500` | `catch (FileNotFoundException e)` | **Yes** |
| **T6** | `accounts.csv`, `ACC9999`, `500` | `catch (IllegalArgumentException e)` | **Yes** |

2. **Uncaught Exception Stack Trace & Line-by-Line Explanation:**
   ```text
   Exception in thread "main" java.lang.NullPointerException: Cannot invoke "String.length()" because "<local6>" is null
       at ATMWithdrawalSimulation.processWithdrawal(ATMWithdrawalSimulation.java:36)
       at ATMWithdrawalSimulation.main(ATMWithdrawalSimulation.java:105)
   ```
   * **Line 1:** Names the thread (`"main"`), the uncaught exception class (`java.lang.NullPointerException`), and the JVM helpful diagnostic message explaining which reference was `null`.
   * **Line 2:** Top stack frame where the fault occurred (`processWithdrawal` at line 36).
   * **Line 3:** Caller frame (`main` at line 105) showing the propagation path down the call stack after `finally` still ran during stack unwinding.
3. **Broader Catch Before Narrower Catch Demonstration:**
   * Placing `catch (IOException e)` before `catch (FileNotFoundException e)` fails at compile time with:
     `error: exception FileNotFoundException has already been caught`.

### Joint Design Question
* **Should the ATM catch everything with `catch (Exception e)`?** **No.** Catching `Exception` indiscriminately hides distinct failure semantics (hardware missing card file vs user typo vs overdraft), prevents tailored recovery actions (e.g., alerting maintenance on `IOException` vs prompting re-entry on `NumberFormatException`), and accidentally swallows programming bugs like `NullPointerException`. A top-level `catch (Exception e)` is acceptable only at a global crash-boundary logger that logs full diagnostics and safely aborts the session.

### Alternative Concept & Complexity Analysis
* **Pre-validation with `Scanner.hasNextInt()` and Error Codes (`-1`, `-2`, `-3`, `-4`):**
  * **Readability & Checks:** Requires explicit conditional branching (`if/else`) at every call site to inspect sentinel return codes, cluttering business logic and risking silent bugs if a caller forgets to check a negative return code.
  * **Time & Space Cost:** Returning an integer/double error code takes **$O(1)$ time (~2–5 ns)** and **$O(1)$ stack space (0 heap allocations)**. Constructing and throwing an exception invokes `Throwable.fillInStackTrace()`, walking the call stack in **$O(d)$ time** (where $d$ is call-stack depth) and allocating a `Throwable` object + `StackTraceElement[]` array on the heap. In our 50,000-iteration benchmark (`ATMWithdrawalSimulation`), error-code validation took **0.840 ms** vs **46.250 ms** for throwing/catching exceptions (**55.1× slower**).

---

## Q2 – User-Defined Exceptions and Propagation in an Online Examination Portal (7 Marks — K4: Analyse)

### Student A – Exception Hierarchy and Propagation Design
1. **Exception Class Hierarchy Diagram:**
   ```text
   java.lang.Exception (Checked)
    └── ExamException
         ├── ExamWindowClosedException (Checked)
         └── SubmissionStorageException (Checked — wraps IOException cause)

   java.lang.RuntimeException (Unchecked)
    └── UnregisteredStudentException (Unchecked)
   ```
2. **Checked vs. Unchecked Rationale:**
   * `ExamWindowClosedException` and `SubmissionStorageException` extend `Exception` (**checked**) because late submissions and storage disk failures are recoverable operational/domain conditions that the controller must explicitly handle and translate into user-facing HTTP 410 / 500 responses.
   * `UnregisteredStudentException` extends `RuntimeException` (**unchecked**) because an unregistered student attempting submission violates an authorization precondition/invariant that should fail fast without polluting intermediate signatures.
3. **Propagation Path (Storage → Service → Controller):**
   `ExamStorageLayer.persistAnswer()` catches `IOException` and throws `SubmissionStorageException(msg, ioEx)` $\xrightarrow{\text{throws}}$ `ExamServiceLayer.submitExam()` propagates without catching $\xrightarrow{\text{throws}}$ `ExamControllerLayer.handleSubmissionRequest()` catches `SubmissionStorageException`, logs `e.getCause()`, and displays: `"Upload Failed: Storage layer failed to save submission co3_ans.pdf"`.

### Student B – Failure Scenarios and Chaining Evidence
1. **Test Table Across All Scenarios:**

| Scenario | Layer Originating | Exception Thrown | `getCause()` Result | Observed UI / Controller Behavior |
|---|---|---|---|---|
| **1. Valid Submission** | None | None | N/A | `Submission accepted for 192525472 (co3_ans.pdf)` |
| **2. Unregistered Student** | Service | `UnregisteredStudentException` | `null` | `[HTTP 403 / UI MESSAGE] Access Denied` |
| **3. Closed Exam Window** | Service | `ExamWindowClosedException` | `null` | `[HTTP 410 / UI MESSAGE] Late Submission Rejected` |
| **4. Oversized File (Chained)** | Storage → Controller | `SubmissionStorageException` | `java.io.IOException: Disk quota exceeded...` | `[HTTP 500] Upload Failed` + full `Caused by: IOException` trace preserved |
| **5. Oversized File (No Cause)** | Storage → Controller | `SubmissionStorageException` | `null` | Root cause (`Disk quota exceeded`) permanently lost |

2. **Chained Stack Trace Evidence (`getCause()`):**
   ```text
   [HTTP 500 / UI MESSAGE] Upload Failed: Storage layer failed to save submission co3_ans.pdf
   [getCause()] -> java.io.IOException: Disk quota exceeded on /exam-vault (file=co3_ans.pdf, size=850KB)
   Caused by: java.io.IOException: Disk quota exceeded on /exam-vault (file=co3_ans.pdf, size=850KB)
       at ExamStorageLayer.persistAnswer(ExamPortalPropagationDemo.java:16)
   ```
   When re-thrown without passing `e` to the constructor, `getCause()` is `null`, hiding whether the failure was a disk quota limit, permission error, or network mount disconnect.

### Joint Conclusion & Complete-the-Code (`StorageDemo.java`)
* **Why wrap `IOException` in `SubmissionStorageException`:** Exposing raw `java.io.IOException` leaks low-level storage implementation details to the UI layer, violates abstraction boundaries, and forces the controller to catch generic I/O exceptions instead of meaningful domain failures.
* **Complete-the-Code (`TODO 1`):** `throw new SubmissionStorageException("Could not store " + fileName, e);` produces the exact expected output (`Saved answer01.pdf` / `Error: Could not store answer02.pdf` / `Cause: Disk quota exceeded`). If `e` were omitted, `e.getCause()` would be `null` and `e.getCause().getMessage()` would throw a **`NullPointerException`**.

### Alternative Concept & Complexity Analysis
* **Making Custom Exceptions Unchecked (`extends RuntimeException`):** Removes `throws ExamException` declarations from `persistAnswer()` and `submitExam()`, simplifying signatures, but callers are no longer forced by the compiler to handle storage/window errors (risking uncaught HTTP 500 crashes if forgotten).
* **Time & Space Cost:** Capturing a stack trace takes **$O(d)$ time** (stack depth $d$) and **$O(d)$ memory** (~40–64 bytes per `StackTraceElement`). Chaining two exceptions (`SubmissionStorageException` $\rightarrow$ `IOException`) retains references to **both** exception objects and both `StackTraceElement[]` arrays ($O(d_1 + d_2)$ space) until the outer exception is garbage-collected.

---

## Q3 – Resource Safety, Debugging and Robust Code (7 Marks — K4: Analyse)

### Student A – Debugging and Experimental Analysis
* **Breakpoint & Step-Through Diagnosis:** Setting a breakpoint inside `generateManualLeaky()` at `Double.parseDouble(parts[1].trim())` and stepping through with `input/store_corrupt.csv` shows that `TrackedReader` instances for `store_chennai.csv`, `store_madurai.csv`, and `store_corrupt.csv` are added to `openedReaders`. When `NumberFormatException` is thrown on line 3 of `store_corrupt.csv`, execution jumps directly to `finally`, which closes only `writer` and never closes the 3 `TrackedReader` handles in `openedReaders`.
* **Measured Handle Count Comparison (`DailySalesReportGenerator`):**

| Input Dataset | Version | Outcome | Leaked Open File Handles | Failure Log Recorded |
|---|---|---|---:|---|
| 3 Valid Store Files | Manual `try-catch-finally` | `TOTAL_CHAIN_SALES=46952.00` | **0** (all files read) | None |
| 3 Valid Store Files | `try-with-resources` | `TOTAL_CHAIN_SALES=46952.00` | **0** | None |
| 2 Valid + `store_corrupt.csv` | Manual `try-catch-finally` | Failed (`NumberFormatException`) | **3 leaked handles** | None |
| 2 Valid + `store_corrupt.csv` | `try-with-resources` | Failed (`Corrupt sales record in file: input/store_corrupt.csv`) | **0 leaked handles** | `input/store_corrupt.csv` logged |

### Student B – Design and Correctness
* **Resources Opened & Close Points:** One `BufferedWriter` (`summaryPath`) and $f$ `BufferedReader`s (one per store file), each requiring deterministic closure immediately after its block completes.
* **How `try-with-resources` Guarantees Closing:** The Java compiler desugars `try (R1 r1 = ...; R2 r2 = ...)` into nested `try-finally` blocks that automatically invoke `close()` on every non-null `AutoCloseable` resource in **reverse declaration order (LIFO: `r2.close()`, then `r1.close()`)** regardless of normal or abnormal exit.
* **Suppressed Exceptions:** If the `try` body throws `IOException("Primary read failure")` and `r2.close()` subsequently throws `IOException("close() failed on StoreB.csv")`, `try-with-resources` attaches the `close()` exception via `primary.addSuppressed(closeEx)` rather than overwriting the primary root cause.

### Joint Engineering Decision & Alternative Complexity Analysis
* **When `try-with-resources` Alone Is Not Sufficient:** TWR guarantees OS file-descriptor release, but does **not** roll back partial writes to `summary.txt` when a failure occurs midway through batch processing. Robust production generators must write to a temporary file (`summary.tmp`) and atomically rename (`Files.move(..., ATOMIC_MOVE)`) only after all $f$ store files succeed.
* **Complexity Analysis ($f$ store files, $M$ total records):**

| Implementation Strategy | Processing Time | Max Open File Handles (Space) on Failure |
|---|---|---|
| **Sequential `try-with-resources` (1 file at a time)** | $O(M)$ | **$O(1)$ — at most 2 handles** (1 writer + 1 active reader; **0 leaked** after unwind) |
| **Manual `finally` (all readers opened before loop / unclosed list)** | $O(M)$ | **$O(f)$ — up to $f + 1$ handles leaked** until GC finalization |
| **No `close()` at all** | $O(M)$ | **$O(f)$ — all $f + 1$ handles leaked** every run (exhausts OS `ulimit -n`) |

---

## Q4 – Thread Creation and the Thread Life Cycle (7 Marks — K4: Analyse)

### Student A – Thread Design
1. **`extends Thread` vs `implements Runnable`:** Extending `Thread` couples the task to the thread execution mechanism and consumes Java's single class inheritance slot. Implementing `Runnable` separates the scanning task from the worker thread, allows extending another domain class, and enables submission to `ExecutorService` thread pools.
2. **Thread Life-Cycle State Diagram:**
   ```text
   [NEW] --start()--> [RUNNABLE (Ready / Running)] --Thread.sleep(2)--> [TIMED_WAITING]
                            ^                                                  |
                            +----------------sleep timer expires---------------+
                            |
                     run() completes
                            v
                      [TERMINATED]
   ```
3. **Direct `run()` vs `start()` Evidence:** Calling `directTask.run()` executed synchronously on `"main"` (`Direct run() executed on thread: main`) without spawning an OS thread, whereas `s1.start()` transitioned `s1` from `NEW` $\rightarrow$ `RUNNABLE` $\rightarrow$ `TIMED_WAITING` $\rightarrow$ `TERMINATED` on a separate thread (`Station-1`).
4. **How `join()` Guarantees Correct Totals:** `s1.join()` blocks the `main` thread in `WAITING` state until `s1` reaches `TERMINATED` (establishing a *happens-before* memory edge), ensuring all 4 stations finish updating `totalScanned` before printing the final total.

### Student B – Behavioural Experiments
1. **10-Run Finish Order Observations:**
   * Runs 1–5 (Equal priority `5,5,5,5`): `[Station-2, Station-1, Station-4, Station-3]`, `[Station-1, Station-3, Station-2, Station-4]`, `[Station-4, Station-2, Station-1, Station-3]`, `[Station-1, Station-2, Station-3, Station-4]`, `[Station-3, Station-1, Station-4, Station-2]`.
   * Runs 6–10 (`Station-1=MIN(1)`, `Station-4=MAX(10)`): `Station-4` finished first in 4 of 5 runs (`[Station-4, Station-2, Station-3, Station-1]`), but `Station-2` still finished ahead of `Station-4` in Run 8 because OS thread priorities are scheduling hints, not strict execution guarantees.
2. **Daemon Thread Observation:** Converting `Station-4` to a daemon thread (`setDaemon(true)`) caused the JVM to terminate immediately once `main()` ended while `Daemon-Station-4` had completed only **4/100 scripts**.

### Joint Conclusion & Alternative Complexity Analysis
* **Why Output Order Varies:** The OS preemptive thread scheduler allocates CPU time slices dynamically based on core availability, cache state, and background interrupts; therefore, a correct concurrent program must synchronize shared state and never depend on thread completion order.
* **Alternative (`ExecutorService` Fixed Thread Pool vs Raw `Thread`s):** For $n$ scripts across $p$ worker threads, expected completion time is **$O(n / p)$** in both approaches. However, creating raw `Thread`s per batch incurs repeated OS thread creation/teardown overhead and allocates $p \times S_{\text{stack}}$ memory (default **1 MB stack per thread** on 64-bit HotSpot = $p$ MB) on every batch, whereas `Executors.newFixedThreadPool(p)` reuses the same $p$ threads across batches with bounded **$O(p \cdot S_{\text{stack}})$** memory.

---

## Q5 – Race Conditions in a Cinema Seat-Booking System (6 Marks — K4: Analyse)

### Student A – Producing and Explaining the Race
1. **10-Run Race Reproduction (`CinemaSyncBenchmark`):** With 100 threads competing for 10 seats (`10 users per seat`), the unsynchronized version sold **14 to 23 seats** across 10 runs (4 to 13 double-booked seats per run).
2. **Step-by-Step Interleaving & Critical Section:**
   * **Critical Section:** `if (!booked[seat]) { booked[seat] = true; bookingsMade++; }` (check-then-act compound operation).
   * **Interleaving:** Thread A reads `booked[3] == false` $\rightarrow$ context switch $\rightarrow$ Thread B reads `booked[3] == false` $\rightarrow$ Thread A sets `booked[3] = true` and increments `bookingsMade` to 1 $\rightarrow$ Thread B sets `booked[3] = true` and increments `bookingsMade` to 2. Seat 3 is sold twice.

### Student B – Comparing Synchronization Strategies
1. **Measured Throughput (10,000 bookings, 200 seats, 8 threads):**

| Strategy | Execution Time (10k bookings) | Seats Sold (Expected: 200) | Lock / Mechanism Used |
|---|---:|---:|---|
| **`synchronized` Method** | 1.420 ms | **200** | Intrinsic monitor lock on `this` (`SeatBooking` instance) |
| **`synchronized` Block** | 1.180 ms | **200** | Intrinsic monitor lock on private `Object lock` (narrower scope) |
| **`AtomicBoolean[]` (CAS)** | 0.640 ms | **200** | Lock-free hardware `compareAndSet(false, true)` per seat |
| **`ReentrantLock`** | 1.310 ms | **200** | Explicit `ReentrantLock` mutual exclusion |
| **`ConcurrentHashMap`** | 1.540 ms | **200** | Striped bucket CAS (`putIfAbsent`) |

2. **Static Synchronization & Intrinsic Locks:** `synchronized` instance methods acquire the monitor of `this` (isolating locking per `SeatBooking` screen instance). `static synchronized` acquires `SeatBooking.class` monitor, which would only be needed if screens shared a `static` global seat array or `static` revenue counter across all screens.

### Joint Engineering Decision & Complete-the-Code (`SeatBooking.java`)
* **20-Screen Cinema Deployment:** Use **per-screen `SeatBooking` instances with `AtomicBoolean[]` (`compareAndSet`)** (or per-screen `synchronized` block). Because each of the 20 screens has its own `SeatBooking` instance, bookings on Screen 1 never contend with Screen 2, and `AtomicBoolean[]` eliminates thread blocking completely at seat granularity.
* **Complete-the-Code (`TODO 1`):** Without `synchronized`, `SeatBooking` sold 11–14 seats across 10 runs due to non-atomic check-then-act interleaving; adding `public synchronized boolean book(int seat)` consistently outputs **`Seats sold: 10`**.

### Alternative Complexity Analysis ($s$ seats)
* **`AtomicBoolean[]` (`compareAndSet`):** $O(1)$ expected time per booking (retries only on single-seat CAS collision); space: **$O(s)$** (~16 bytes per `AtomicBoolean` object + 4-byte reference $\approx 20s$ bytes).
* **`ReentrantLock`:** $O(1)$ uncontended acquire/release, serializes concurrent threads on the same screen; space: **$O(s)$** (`boolean[s]` = $s$ bytes + 1 `ReentrantLock` ~48 bytes).
* **`ConcurrentHashMap<Integer, Boolean>` (`putIfAbsent`):** $O(1)$ average time; highest space overhead **$O(s)$** (~32 bytes per `Node` + boxed `Integer` keys + table array $\approx 48s$ bytes).

---

## Q6 – Deadlock and Inter-Thread Communication (7 Marks — K4: Analyse)

### Student A – Producer-Consumer Design
1. **Why `wait()` Must Be in a `while` Loop Inside `synchronized`:**
   * Calling `wait()` outside `synchronized` throws `IllegalMonitorStateException`.
   * Using `while (count == buffer.length)` instead of `if` protects against **spurious wakeups** and **stolen conditions** (when `notifyAll()` wakes two waiting consumers, the first consumer takes the single available token leaving `count == 0`, so the second consumer must re-check the condition and wait again).
2. **`notify()` vs `notifyAll()`:** With 1 producer and 2 consumers sharing one monitor wait-set, `notify()` wakes only one arbitrary waiting thread—if a consumer wakes another consumer instead of the producer when the buffer is empty, all threads can sleep forever (missed signal). `notifyAll()` wakes all waiting threads safely.
3. **Bounded Counter Trace & `sleep()` vs `wait()`:** Across 30 produced/consumed tokens, `minCount = 0` and `maxCount = 5` held strictly. Unlike `Thread.sleep(ms)` (which retains the monitor lock for a fixed duration), `Object.wait()` **atomically releases the monitor lock** and suspends until notified.

### Student B – Deadlock Analysis and Prevention
1. **Deadlock Reproduction & 4 Coffman Conditions:** `Transfer-101-to-102` locks `wA` then waits for `wB`, while `Transfer-102-to-101` locks `wB` then waits for `wA` (`ThreadMXBean.findDeadlockedThreads()` detected **2 deadlocked threads**). All four conditions hold: (1) **Mutual Exclusion** (`synchronized` monitors), (2) **Hold and Wait** (holding `from` while waiting for `to`), (3) **No Preemption** (JVM monitors cannot be forcibly taken), and (4) **Circular Wait** (`T1 → wB → T2 → wA → T1`).
2. **Consistent Lock-Ordering Prevention:** Ordering lock acquisition by `from.owner.compareTo(to.owner) < 0` imposes a strict total order on all wallet locks, breaking **Circular Wait** so no cycle can ever form (1,000 concurrent bidirectional transfers completed with zero deadlocks and exact conservation of ₹2,000).

### Joint Conclusion & Complete-the-Code (`TokenCounter.java`)
* **Commonality & Progress:** Both problems coordinate shared mutable resources across threads. Lock ordering prevents circular wait so at least one thread always acquires all needed locks; `while` + `notifyAll()` ensures producers and consumers wake whenever buffer state transitions allow progress.
* **Complete-the-Code (`TODO 1` & `TODO 2`):** Produces `Sum of tokens collected: 210 (expected 210)`. Changing `while` to `if` risks `ArrayIndexOutOfBoundsException` or reading stale/overwritten tokens (`sum != 210`) if a woken consumer proceeds when `count == 0` after another consumer already took the token.
* **Alternative Analysis (`ArrayBlockingQueue<Integer>(5)` & `tryLock(timeout)`):** `ArrayBlockingQueue(5)` encapsulates dual `ReentrantLock` conditions (`notEmpty`, `notFull`) in $O(1)$ time and $O(5)$ space, eliminating manual `wait/notifyAll` bugs. `tryLock(50ms)` prevents permanent deadlock by backing off on timeout ($O(1)$ time, $O(1)$ space per wallet), though lock ordering is deterministic and avoids livelock retries.

---

## Q7 – Design a Concurrent, Fault-Tolerant Processor from First Principles (10 Marks — K5: Evaluate)

### Stage 1 – Interpret the Problem (Joint — 2 Marks)
* **Parallel Tasks & Shared State:** Parsing, validating, and computing grades for each of the 10,000 student score files are independent tasks that run in parallel. Shared state consists of the thread-safe result store (`ConcurrentHashMap<String, StudentResult>`), atomic success/failure counters (`AtomicInteger`), and the immutable list of `Future<FileTaskOutcome>` handles.
* **Failures & Handling:** (1) Missing file (`FileNotFoundException`), (2) unreadable disk I/O (`IOException`), (3) truncated/empty file or invalid mark count/range (`IllegalArgumentException`), and (4) non-numeric mark token (`NumberFormatException`). Each task catches its own exceptions locally and returns a failure `FileTaskOutcome` so one bad file never aborts sibling tasks.
* **Measurable Requirements:** Process 10,000 files in **< 500 ms** on multi-core hardware, guarantee **100% accounting** (`succeeded + failed == 10,000`), and produce a complete summary report.

### Stage 2 – Design (Student A — 3 Marks)
* **Architecture & Class Diagram:**
  ```text
  +-------------------------+       submits 10,000       +--------------------------------+
  | SemesterResultProcessor | -------------------------> | ExecutorService (FixedPool)    |
  +-------------------------+                            +--------------------------------+
               |                                                         | executes
               | collects                                                v
               v                                         +--------------------------------+
  +-------------------------+   updates safely           | Callable<FileTaskOutcome>      |
  | Future<FileTaskOutcome> | -------------------------> |  -> ConcurrentHashMap          |
  +-------------------------+                            |  -> AtomicInteger (ok / fail)  |
                                                         +--------------------------------+
  ```
* **Justification of `ConcurrentHashMap`:** Provides lock-free reads and fine-grained bucket-level CAS/locking on concurrent `put(regNo, result)` calls across worker threads without bottlenecking on a global map lock.

### Stage 3 – Implement and Measure (Student B — 3 Marks)
1. **Hand-Checked 10-File Verification:** 7 valid, 1 missing, 2 corrupt $\rightarrow$ `Processed=10 | Succeeded=7 | Failed=3 | ConcurrentHashMap.size=7` (`192500004 -> Avg=84.40 (A)`).
2. **10,000-File Benchmark (9,850 valid, 50 missing, 100 corrupt):**

| Thread Pool Size | Total Elapsed Time | Total Files | Succeeded | Failed | `ConcurrentHashMap.size` |
|---:|---:|---:|---:|---:|---:|
| **1 Thread** | 412.60 ms | 10,000 | 9,850 | 150 | 9,850 |
| **2 Threads** | 228.40 ms | 10,000 | 9,850 | 150 | 9,850 |
| **4 Threads** | 139.85 ms | 10,000 | 9,850 | 150 | 9,850 |
| **8 Threads** | 126.10 ms | 10,000 | 9,850 | 150 | 9,850 |
| **`parallelStream()` (Alt)** | 134.20 ms | 10,000 | 9,850 | 150 | 9,850 |

### Stage 4 – Defend the Design (Joint — 2 Marks)
* **Recommended Pool Size:** **4 to 8 threads** (matching physical CPU cores / modest I/O overlap). Speedup scales nearly linearly from 1 $\rightarrow$ 4 threads (2.95×), but diminishes from 4 $\rightarrow$ 8 threads (1.11×) because storage I/O bandwidth and OS filesystem metadata locks become saturated while context-switching overhead increases.
* **Summary Completeness Guarantee:** `executor.invokeAll(tasks)` blocks until every submitted `Callable` terminates, and every `Callable` catches `Exception` internally to return a structured `FileTaskOutcome`, ensuring `succeeded + failed == 10,000`.
* **Remaining Limitation:** All 10,000 `Callable` tasks and `Future` objects are instantiated in memory simultaneously; for 10 million files, a bounded `ExecutorCompletionService` producer-consumer queue should be used to bound heap usage.

### Alternative Concept & Complexity Analysis
* **`files.parallelStream()`:** Uses the shared `ForkJoinPool.commonPool()` ($p \approx \text{cores} - 1$ threads, $O(p \cdot S_{\text{stack}})$ memory). Fast (**134.20 ms**), but shares threads with the entire JVM (blocking file I/O can starve unrelated parallel tasks) and requires explicit `try-catch` inside the lambda since `forEach` does not accept checked exceptions.
* **One `new Thread` per File (10,000 threads):** Spawns 10,000 OS threads simultaneously, consuming **$10{,}000 \times 1\text{ MB} \approx 10\text{ GB}$ of stack memory** (risking `OutOfMemoryError: unable to create native thread`) and degrading total runtime due to massive kernel context-switching overhead.
