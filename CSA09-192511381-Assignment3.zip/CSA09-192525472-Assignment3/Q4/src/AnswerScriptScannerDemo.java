import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class AnswerScriptScannerDemo {

    static class StationThread extends Thread {
        private final int batchSize;
        private final List<String> completionOrder;
        private final AtomicInteger totalScanned;

        StationThread(String name, int batchSize, List<String> completionOrder, AtomicInteger totalScanned) {
            super(name);
            this.batchSize = batchSize;
            this.completionOrder = completionOrder;
            this.totalScanned = totalScanned;
        }

        @Override
        public void run() {
            for (int i = 1; i <= batchSize; i++) {
                try {
                    Thread.sleep(2);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
            totalScanned.addAndGet(batchSize);
            completionOrder.add(getName());
        }
    }

    static class StationRunnable implements Runnable {
        private final String stationName;
        private final int batchSize;
        private final List<String> completionOrder;
        private final AtomicInteger totalScanned;

        StationRunnable(String stationName, int batchSize, List<String> completionOrder, AtomicInteger totalScanned) {
            this.stationName = stationName;
            this.batchSize = batchSize;
            this.completionOrder = completionOrder;
            this.totalScanned = totalScanned;
        }

        @Override
        public void run() {
            for (int i = 1; i <= batchSize; i++) {
                try {
                    Thread.sleep(2);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    return;
                }
            }
            totalScanned.addAndGet(batchSize);
            completionOrder.add(stationName);
        }
    }

    static List<String> runOnceWithPriorities(int[] priorities) throws InterruptedException {
        List<String> finishOrder = Collections.synchronizedList(new ArrayList<>());
        AtomicInteger total = new AtomicInteger(0);
        Thread[] stations = new Thread[4];
        for (int i = 0; i < 4; i++) {
            stations[i] = new Thread(new StationRunnable("Station-" + (i + 1), 15, finishOrder, total), "Station-" + (i + 1));
            stations[i].setPriority(priorities[i]);
        }
        for (Thread t : stations) t.start();
        for (Thread t : stations) t.join();
        return finishOrder;
    }

    static void demonstrateThreadLifecycleAndDirectRun() throws InterruptedException {
        System.out.println("--- 1. Thread Life-Cycle States & Direct run() vs start() ---");
        List<String> order = Collections.synchronizedList(new ArrayList<>());
        AtomicInteger total = new AtomicInteger(0);
        StationThread s1 = new StationThread("Station-1", 10, order, total);

        System.out.println("  State before start() : " + s1.getState() + " | isAlive=" + s1.isAlive());
        Runnable directTask = () -> System.out.println("  Direct run() executed on thread: " + Thread.currentThread().getName());
        directTask.run();

        s1.start();
        System.out.println("  State right after start(): " + s1.getState() + " | isAlive=" + s1.isAlive());
        Thread.sleep(5);
        System.out.println("  State during sleep()     : " + s1.getState() + " | isAlive=" + s1.isAlive());
        s1.join();
        System.out.println("  State after join()       : " + s1.getState() + " | isAlive=" + s1.isAlive()
                + " | Total=" + total.get() + "\n");
    }

    static void demonstrateDaemonBehavior() throws InterruptedException {
        System.out.println("--- 3. Daemon Station Thread Behavior ---");
        AtomicInteger daemonProgress = new AtomicInteger(0);
        Thread daemonStation = new Thread(() -> {
            for (int i = 1; i <= 100; i++) {
                daemonProgress.set(i);
                try { Thread.sleep(5); } catch (InterruptedException e) { break; }
            }
        }, "Daemon-Station-4");
        daemonStation.setDaemon(true);
        daemonStation.start();
        Thread.sleep(18);
        System.out.println("  Non-daemon main work finishing while Daemon-Station-4 scanned only "
                + daemonProgress.get() + "/100 scripts (JVM terminates daemon immediately upon main exit).\n");
    }

    static void benchmarkExecutorService(int totalScripts, int poolSize) throws Exception {
        long t0 = System.nanoTime();
        ExecutorService pool = Executors.newFixedThreadPool(poolSize);
        AtomicInteger processed = new AtomicInteger(0);
        int perStation = totalScripts / poolSize;
        for (int i = 0; i < poolSize; i++) {
            pool.submit(() -> {
                long work = 0;
                for (int s = 0; s < perStation; s++) {
                    for (int k = 0; k < 500; k++) work += (s ^ k);
                    processed.incrementAndGet();
                }
                if (work == -1) System.out.println(work);
            });
        }
        pool.shutdown();
        pool.awaitTermination(10, TimeUnit.SECONDS);
        double ms = (System.nanoTime() - t0) / 1e6;
        System.out.printf("  ExecutorService (p=%d threads, n=%d scripts): %7.3f ms | Scanned=%d%n",
                poolSize, totalScripts, ms, processed.get());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Q4: Parallel Answer-Script Scanning & Thread Life Cycle ===\n");
        demonstrateThreadLifecycleAndDirectRun();

        System.out.println("--- 2. Ten Runs Recording Finish Order (Default vs Custom Priorities) ---");
        for (int run = 1; run <= 10; run++) {
            int[] prios = (run <= 5)
                    ? new int[]{Thread.NORM_PRIORITY, Thread.NORM_PRIORITY, Thread.NORM_PRIORITY, Thread.NORM_PRIORITY}
                    : new int[]{Thread.MIN_PRIORITY, Thread.NORM_PRIORITY, Thread.NORM_PRIORITY, Thread.MAX_PRIORITY};
            String label = (run <= 5) ? "Equal(5,5,5,5)" : "Prio(1,5,5,10)";
            System.out.printf("  Run %2d [%s] -> Finish Order: %s%n", run, label, runOnceWithPriorities(prios));
        }
        System.out.println();

        demonstrateDaemonBehavior();

        System.out.println("--- 4. Alternative Concept: Fixed Thread Pool ExecutorService (n=40,000 scripts) ---");
        benchmarkExecutorService(40_000, 1);
        benchmarkExecutorService(40_000, 2);
        benchmarkExecutorService(40_000, 4);
    }
}
