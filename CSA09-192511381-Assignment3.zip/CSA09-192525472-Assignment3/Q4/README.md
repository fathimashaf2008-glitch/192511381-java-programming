# Q4 – Thread Creation and the Thread Life Cycle

* Implements parallel answer-script scanning using both `extends Thread` and `implements Runnable`, inspects all 6 `Thread.State` lifecycle transitions (`NEW`, `RUNNABLE`, `TIMED_WAITING`, `TERMINATED`), logs 10 runs with default and custom priorities, demonstrates daemon termination, and benchmarks `ExecutorService`.

## Run
```sh
sh run.sh
```
