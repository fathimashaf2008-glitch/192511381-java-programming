# Q3 – Resource Safety, Debugging and Robust Code

* Compares manual `try-catch-finally` resource cleanup (leaking 3 open file handles when a mid-batch failure occurs) against `try-with-resources` (0 leaked handles, LIFO close order, and suppressed exception preservation).

## Run
```sh
sh run.sh
```
