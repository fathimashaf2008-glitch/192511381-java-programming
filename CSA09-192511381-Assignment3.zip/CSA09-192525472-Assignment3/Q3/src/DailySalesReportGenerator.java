import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class DailySalesReportGenerator {

    static class TrackedReader extends BufferedReader {
        private static int openHandles = 0;
        private final String fileName;
        private boolean closed = false;

        TrackedReader(String fileName) throws IOException {
            super(new FileReader(fileName));
            this.fileName = fileName;
            openHandles++;
        }

        @Override
        public void close() throws IOException {
            if (!closed) {
                closed = true;
                openHandles--;
            }
            super.close();
        }

        static int getOpenHandles() { return openHandles; }
        static void reset() { openHandles = 0; }
        String getFileName() { return fileName; }
    }

    static class TrackedWriter extends BufferedWriter {
        private static int openHandles = 0;
        private boolean closed = false;

        TrackedWriter(String fileName) throws IOException {
            super(new FileWriter(fileName));
            openHandles++;
        }

        @Override
        public void close() throws IOException {
            if (!closed) {
                closed = true;
                openHandles--;
            }
            super.close();
        }

        static int getOpenHandles() { return openHandles; }
        static void reset() { openHandles = 0; }
    }

    static double generateManualLeaky(List<String> storeFiles, String summaryPath) throws IOException {
        TrackedReader.reset();
        TrackedWriter.reset();
        List<TrackedReader> openedReaders = new ArrayList<>();
        TrackedWriter writer = null;
        double grandTotal = 0.0;
        String currentFile = "NONE";
        try {
            writer = new TrackedWriter(summaryPath);
            for (String f : storeFiles) {
                currentFile = f;
                TrackedReader r = new TrackedReader(f);
                openedReaders.add(r);
                String line;
                while ((line = r.readLine()) != null) {
                    if (line.startsWith("store") || line.trim().isEmpty()) continue;
                    String[] parts = line.split(",");
                    grandTotal += Double.parseDouble(parts[1].trim());
                }
            }
            writer.write(String.format("TOTAL_CHAIN_SALES=%.2f%n", grandTotal));
        } catch (IOException e) {
            System.out.println("  [ERROR LOG] I/O failure while reading file: " + currentFile + " -> " + e.getMessage());
            throw e;
        } finally {
            if (writer != null) {
                writer.close();
            }
        }
        return grandTotal;
    }

    static double generateTryWithResources(List<String> storeFiles, String summaryPath) throws IOException {
        TrackedReader.reset();
        TrackedWriter.reset();
        double grandTotal = 0.0;
        try (TrackedWriter writer = new TrackedWriter(summaryPath)) {
            for (String f : storeFiles) {
                try (TrackedReader reader = new TrackedReader(f)) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.startsWith("store") || line.trim().isEmpty()) continue;
                        String[] parts = line.split(",");
                        grandTotal += Double.parseDouble(parts[1].trim());
                    }
                } catch (NumberFormatException nfe) {
                    throw new IllegalArgumentException("Corrupt sales record in file: " + f, nfe);
                }
            }
            writer.write(String.format("TOTAL_CHAIN_SALES=%.2f%n", grandTotal));
        }
        return grandTotal;
    }

    static void demonstrateSuppressedException() {
        System.out.println("--- Suppressed Exception Demonstration (try-with-resources) ---");
        class FaultyResource implements AutoCloseable {
            final String name;
            FaultyResource(String name) { this.name = name; }
            @Override
            public void close() throws IOException {
                throw new IOException("close() failed on " + name);
            }
        }
        try (FaultyResource r1 = new FaultyResource("StoreA.csv");
             FaultyResource r2 = new FaultyResource("StoreB.csv")) {
            throw new IOException("Primary read failure inside try block");
        } catch (IOException primary) {
            System.out.println("  Primary Exception   : " + primary.getMessage());
            for (Throwable sup : primary.getSuppressed()) {
                System.out.println("  Suppressed Exception: " + sup.getMessage() + " (closed in reverse LIFO order)");
            }
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Q3: Daily Sales Report Generator — Resource Safety & Debugging ===\n");
        List<String> validFiles = List.of("input/store_chennai.csv", "input/store_madurai.csv", "input/store_coimbatore.csv");
        List<String> failingFiles = List.of("input/store_chennai.csv", "input/store_madurai.csv", "input/store_corrupt.csv");

        double mValid = generateManualLeaky(validFiles, "output/summary_manual.txt");
        int manualOpenValid = TrackedReader.getOpenHandles();
        double twrValid = generateTryWithResources(validFiles, "output/summary_twr.txt");
        int twrOpenValid = TrackedReader.getOpenHandles();

        System.out.printf("1. Valid Run (3 store files):%n");
        System.out.printf("   Manual Total = %.2f (leaked readers = %d) | TWR Total = %.2f (leaked readers = %d)%n\n",
                mValid, manualOpenValid, twrValid, twrOpenValid);

        System.out.println("2. Failing Run (corrupt data in 3rd file):");
        try {
            generateManualLeaky(failingFiles, "output/summary_manual_fail.txt");
        } catch (RuntimeException e) {
            System.out.println("   Manual Version Failed (" + e.getClass().getSimpleName() + ") -> Leaked Open File Handles: "
                    + TrackedReader.getOpenHandles());
        }

        try {
            generateTryWithResources(failingFiles, "output/summary_twr_fail.txt");
        } catch (RuntimeException e) {
            System.out.println("   TWR Version Failed    (" + e.getMessage() + ") -> Leaked Open File Handles: "
                    + TrackedReader.getOpenHandles() + "\n");
        }

        demonstrateSuppressedException();
    }
}
