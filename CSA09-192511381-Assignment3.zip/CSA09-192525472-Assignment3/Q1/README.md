# Q1 – Handling Failure in a Bank ATM Simulation

* **Student A (192525472):** Exception hierarchy design, catch-block ordering justification, `finally` guarantees.
* **Student B:** 6-path test execution, stack trace analysis, and error-code vs exception microbenchmark.

## Run
```sh
sh run.sh
```
