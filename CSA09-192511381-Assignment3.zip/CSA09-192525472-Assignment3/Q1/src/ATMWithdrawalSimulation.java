import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

class InsufficientFundsException extends Exception {
    InsufficientFundsException(String message) { super(message); }
}

class InvalidAmountException extends IllegalArgumentException {
    InvalidAmountException(String message) { super(message); }
}

public class ATMWithdrawalSimulation {

    static Map<String, Double> loadAccountsFromCardReader(String filePath) throws IOException {
        Map<String, Double> accounts = new HashMap<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line = br.readLine();
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty()) continue;
                String[] parts = line.split(",");
                accounts.put(parts[0].trim(), Double.parseDouble(parts[1].trim()));
            }
        }
        return accounts;
    }

    static void processWithdrawal(String cardFile, String rawAccNo, String rawAmount, boolean triggerUncaughtDemo) {
        System.out.println("------------------------------------------------------------");
        System.out.printf("Test Input -> file='%s', acc='%s', amount='%s'%n", cardFile, rawAccNo, rawAmount);
        boolean sessionActive = true;
        try {
            if (triggerUncaughtDemo) {
                String nullPin = null;
                nullPin.length();
            }
            Map<String, Double> db = loadAccountsFromCardReader(cardFile);
            if (!db.containsKey(rawAccNo)) {
                throw new IllegalArgumentException("Unknown account number: " + rawAccNo);
            }
            double amount = Double.parseDouble(rawAmount);
            if (amount <= 0) {
                throw new InvalidAmountException("Withdrawal amount must be positive: " + amount);
            }
            double balance = db.get(rawAccNo);
            if (amount > balance) {
                throw new InsufficientFundsException(
                        String.format("Requested %.2f exceeds available balance %.2f", amount, balance));
            }
            double remaining = balance - amount;
            db.put(rawAccNo, remaining);
            System.out.printf("  [SUCCESS] Dispensed INR %.2f | Remaining Balance: INR %.2f%n", amount, remaining);

        } catch (FileNotFoundException e) {
            System.out.println("  [CAUGHT: FileNotFoundException (Checked)] Card-reader file missing: " + e.getMessage());
        } catch (IOException e) {
            System.out.println("  [CAUGHT: IOException (Checked)] Card-reader I/O failure: " + e.getMessage());
        } catch (NumberFormatException | InvalidAmountException e) {
            System.out.println("  [CAUGHT: Multi-catch (" + e.getClass().getSimpleName() + " - Unchecked)] Invalid input: " + e.getMessage());
        } catch (InsufficientFundsException e) {
            System.out.println("  [CAUGHT: InsufficientFundsException (Checked)] " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("  [CAUGHT: IllegalArgumentException (Unchecked)] " + e.getMessage());
        } finally {
            sessionActive = false;
            System.out.println("  [FINALLY] Card ejected, keypad cleared, sessionActive=" + sessionActive);
        }
    }

    static double withdrawWithErrorCodes(Map<String, Double> db, String acc, String rawAmt) {
        if (db == null || !db.containsKey(acc)) return -1;
        if (rawAmt == null || !rawAmt.matches("\\d+(\\.\\d+)?")) return -2;
        double amt = Double.parseDouble(rawAmt);
        if (amt <= 0) return -3;
        double bal = db.get(acc);
        if (amt > bal) return -4;
        db.put(acc, bal - amt);
        return bal - amt;
    }

    static void benchmarkExceptionVsErrorCode(int iterations) {
        Map<String, Double> db = Map.of("ACC1001", 50000.0);
        for (int i = 0; i < 2000; i++) {
            withdrawWithErrorCodes(db, "ACC1001", "abc");
            try { Integer.parseInt("abc"); } catch (NumberFormatException ignored) {}
        }
        long t0 = System.nanoTime();
        long codeSink = 0;
        for (int i = 0; i < iterations; i++) {
            codeSink += (long) withdrawWithErrorCodes(db, "ACC1001", "abc");
        }
        long codeNs = System.nanoTime() - t0;

        t0 = System.nanoTime();
        long exSink = 0;
        for (int i = 0; i < iterations; i++) {
            try {
                Double.parseDouble("abc");
            } catch (NumberFormatException e) {
                exSink += e.getStackTrace().length;
            }
        }
        long exNs = System.nanoTime() - t0;
        if (codeSink == 999999 && exSink == 999999) System.out.println();

        System.out.println("=== Alternative Concept Benchmark (" + iterations + " invalid-input paths) ===");
        System.out.printf("  Error-Code Validation : %7.3f ms%n", codeNs / 1e6);
        System.out.printf("  Exception Throw+Catch : %7.3f ms (%.1fx slower due to stack trace capture)%n",
                exNs / 1e6, (double) exNs / Math.max(codeNs, 1));
    }

    public static void main(String[] args) {
        System.out.println("=== Q1: Bank ATM Withdrawal Failure & Exception Handling Simulation ===\n");
        String validFile = "input/accounts.csv";

        processWithdrawal(validFile, "ACC1001", "2500", false);
        processWithdrawal(validFile, "ACC1001", "fifty", false);
        processWithdrawal(validFile, "ACC1001", "-500", false);
        processWithdrawal(validFile, "ACC1001", "95000", false);
        processWithdrawal("input/missing_card.csv", "ACC1001", "500", false);
        processWithdrawal(validFile, "ACC9999", "500", false);

        System.out.println();
        benchmarkExceptionVsErrorCode(50_000);
    }
}
