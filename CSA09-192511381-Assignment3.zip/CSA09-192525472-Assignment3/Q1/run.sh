#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out ATMWithdrawalSimulation | tee output/ATMWithdrawalSimulation_output.txt
