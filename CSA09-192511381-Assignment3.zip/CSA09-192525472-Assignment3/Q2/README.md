# Q2 – User-Defined Exceptions and Propagation in an Online Examination Portal

* `src/StorageDemo.java`: Completed `TODO 1` matching exact expected output.
* `src/ExamPortalPropagationDemo.java`: 3-layer (Storage -> Service -> Controller) exception propagation, chaining with `getCause()`, and lost-cause demonstration.

## Run
```sh
sh run.sh
```
