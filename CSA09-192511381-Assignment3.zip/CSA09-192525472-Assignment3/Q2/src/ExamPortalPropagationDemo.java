import java.io.IOException;
import java.util.Set;

class ExamWindowClosedException extends ExamException {
    ExamWindowClosedException(String msg) { super(msg); }
}

class UnregisteredStudentException extends RuntimeException {
    UnregisteredStudentException(String msg) { super(msg); }
}

class ExamStorageLayer {
    void persistAnswer(String studentId, String fileName, long sizeKb) throws SubmissionStorageException {
        try {
            if (sizeKb > 500) {
                throw new IOException("Disk quota exceeded on /exam-vault (file=" + fileName + ", size=" + sizeKb + "KB)");
            }
        } catch (IOException ioEx) {
            throw new SubmissionStorageException("Storage layer failed to save submission " + fileName, ioEx);
        }
    }
}

class ExamServiceLayer {
    private final Set<String> registeredStudents = Set.of("192525472", "192525473");
    private final ExamStorageLayer storage = new ExamStorageLayer();

    void submitExam(String studentId, String courseCode, boolean windowOpen, String fileName, long sizeKb)
            throws ExamException {
        if (!registeredStudents.contains(studentId)) {
            throw new UnregisteredStudentException("Student " + studentId + " is not enrolled in " + courseCode);
        }
        if (!windowOpen) {
            throw new ExamWindowClosedException("Exam submission window closed for " + courseCode);
        }
        storage.persistAnswer(studentId, fileName, sizeKb);
    }
}

class ExamControllerLayer {
    private final ExamServiceLayer service = new ExamServiceLayer();

    void handleSubmissionRequest(String scenario, String studentId, String course, boolean windowOpen,
                                 String fileName, long sizeKb, boolean demonstrateLostCause) {
        System.out.println("Scenario: " + scenario);
        try {
            if (demonstrateLostCause) {
                try {
                    service.submitExam(studentId, course, windowOpen, fileName, sizeKb);
                } catch (SubmissionStorageException chained) {
                    throw new SubmissionStorageException(chained.getMessage(), null);
                }
            } else {
                service.submitExam(studentId, course, windowOpen, fileName, sizeKb);
                System.out.println("  [UI MESSAGE] Submission accepted for " + studentId + " (" + fileName + ")\n");
            }
        } catch (UnregisteredStudentException e) {
            System.out.println("  [HTTP 403 / UI MESSAGE] Access Denied: " + e.getMessage());
            System.out.println("  [getCause()] -> " + e.getCause() + "\n");
        } catch (ExamWindowClosedException e) {
            System.out.println("  [HTTP 410 / UI MESSAGE] Late Submission Rejected: " + e.getMessage());
            System.out.println("  [getCause()] -> " + e.getCause() + "\n");
        } catch (SubmissionStorageException e) {
            System.out.println("  [HTTP 500 / UI MESSAGE] Upload Failed: " + e.getMessage());
            System.out.println("  [getCause()] -> " + e.getCause());
            System.out.println("  [Chained Stack Trace Preview]:");
            for (StackTraceElement ste : e.getStackTrace()) {
                System.out.println("    at " + ste);
            }
            if (e.getCause() != null) {
                System.out.println("  Caused by: " + e.getCause());
                for (StackTraceElement ste : e.getCause().getStackTrace()) {
                    System.out.println("    at " + ste);
                }
            }
            System.out.println();
        } catch (ExamException e) {
            System.out.println("  [GENERAL EXAM ERROR] " + e.getMessage() + "\n");
        }
    }
}

public class ExamPortalPropagationDemo {
    public static void main(String[] args) {
        System.out.println("=== Q2: Online Examination Portal Multi-Layer Exception Propagation ===\n");
        ExamControllerLayer controller = new ExamControllerLayer();

        controller.handleSubmissionRequest("1. Valid Submission", "192525472", "CSA09", true, "co3_ans.pdf", 240, false);
        controller.handleSubmissionRequest("2. Unregistered Student (Unchecked)", "192599999", "CSA09", true, "co3_ans.pdf", 240, false);
        controller.handleSubmissionRequest("3. Closed Exam Window (Checked)", "192525472", "CSA09", false, "co3_ans.pdf", 240, false);
        controller.handleSubmissionRequest("4. Oversized File with Chaining (Checked)", "192525472", "CSA09", true, "co3_ans.pdf", 850, false);
        controller.handleSubmissionRequest("5. Oversized File WITHOUT Cause (Anti-Pattern)", "192525472", "CSA09", true, "co3_ans.pdf", 850, true);
    }
}
