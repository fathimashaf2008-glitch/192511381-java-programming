#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out StorageDemo | tee output/StorageDemo_output.txt
java -cp out ExamPortalPropagationDemo | tee output/ExamPortalPropagationDemo_output.txt
