import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantLock;

public class HostelDeadlockAndCounterDemo {

    static class Wallet {
        final String owner;
        int balance;
        final ReentrantLock lock = new ReentrantLock();

        Wallet(String owner, int balance) {
            this.owner = owner;
            this.balance = balance;
        }
    }

    static void unsafeTransfer(Wallet from, Wallet to, int amount) {
        synchronized (from) {
            try { Thread.sleep(20); } catch (InterruptedException ignored) {}
            synchronized (to) {
                from.balance -= amount;
                to.balance += amount;
            }
        }
    }

    static void safeOrderedTransfer(Wallet from, Wallet to, int amount) {
        Wallet first = from.owner.compareTo(to.owner) < 0 ? from : to;
        Wallet second = (first == from) ? to : from;
        synchronized (first) {
            synchronized (second) {
                from.balance -= amount;
                to.balance += amount;
            }
        }
    }

    static boolean safeTryLockTransfer(Wallet from, Wallet to, int amount) throws InterruptedException {
        if (from.lock.tryLock(50, TimeUnit.MILLISECONDS)) {
            try {
                if (to.lock.tryLock(50, TimeUnit.MILLISECONDS)) {
                    try {
                        from.balance -= amount;
                        to.balance += amount;
                        return true;
                    } finally {
                        to.lock.unlock();
                    }
                }
            } finally {
                from.lock.unlock();
            }
        }
        return false;
    }

    static void demonstrateDeadlockDetectionAndPrevention() throws InterruptedException {
        System.out.println("--- Part A: Hostel Wallet Deadlock Detection & Lock-Ordering Prevention ---");
        Wallet wA = new Wallet("STU-101", 1000);
        Wallet wB = new Wallet("STU-102", 1000);

        Thread t1 = new Thread(() -> unsafeTransfer(wA, wB, 100), "Transfer-101-to-102");
        Thread t2 = new Thread(() -> unsafeTransfer(wB, wA, 150), "Transfer-102-to-101");
        t1.setDaemon(true);
        t2.setDaemon(true);
        t1.start();
        t2.start();
        Thread.sleep(80);

        ThreadMXBean bean = ManagementFactory.getThreadMXBean();
        long[] deadlockedIds = bean.findDeadlockedThreads();
        System.out.println("  Unsafe opposite transfers -> Deadlocked thread count detected by JVM: "
                + (deadlockedIds == null ? 0 : deadlockedIds.length)
                + " (t1=" + t1.getState() + ", t2=" + t2.getState() + ")");

        Wallet s1 = new Wallet("STU-201", 1000);
        Wallet s2 = new Wallet("STU-202", 1000);
        Thread st1 = new Thread(() -> {
            for (int i = 0; i < 500; i++) safeOrderedTransfer(s1, s2, 1);
        });
        Thread st2 = new Thread(() -> {
            for (int i = 0; i < 500; i++) safeOrderedTransfer(s2, s1, 1);
        });
        st1.start(); st2.start();
        st1.join(); st2.join();
        System.out.printf("  Consistent Lock-Ordering (1000 bidirectional transfers) -> Completed cleanly! s1=%d, s2=%d (Sum=%d)%n\n",
                s1.balance, s2.balance, s1.balance + s2.balance);
    }

    static void traceBoundedCounterBounds() throws InterruptedException {
        System.out.println("--- Part B: Mess Token Counter Bounds Trace (0 <= count <= 5) ---");
        class InstrumentedCounter {
            private final int[] buf = new int[5];
            private int count = 0, in = 0, out = 0;
            int minSeen = 0, maxSeen = 0;

            synchronized void put(int tok) throws InterruptedException {
                while (count == 5) wait();
                buf[in] = tok;
                in = (in + 1) % 5;
                count++;
                if (count > maxSeen) maxSeen = count;
                notifyAll();
            }

            synchronized int take() throws InterruptedException {
                while (count == 0) wait();
                int tok = buf[out];
                out = (out + 1) % 5;
                count--;
                if (count < minSeen) minSeen = count;
                notifyAll();
                return tok;
            }
        }

        InstrumentedCounter ic = new InstrumentedCounter();
        Thread producer = new Thread(() -> {
            try {
                for (int i = 1; i <= 30; i++) ic.put(i);
            } catch (InterruptedException ignored) {}
        });
        Thread[] consumers = new Thread[3];
        for (int c = 0; c < 3; c++) {
            consumers[c] = new Thread(() -> {
                try {
                    for (int k = 0; k < 10; k++) ic.take();
                } catch (InterruptedException ignored) {}
            });
        }
        producer.start();
        for (Thread c : consumers) c.start();
        producer.join();
        for (Thread c : consumers) c.join();
        System.out.printf("  30 tokens produced & consumed by 3 students -> minCount=%d, maxCount=%d (Invariant 0..5 holds)%n",
                ic.minSeen, ic.maxSeen);

        ArrayBlockingQueue<Integer> abq = new ArrayBlockingQueue<>(5);
        for (int i = 1; i <= 5; i++) abq.put(i);
        System.out.println("  Alternative ArrayBlockingQueue(5) size at capacity: " + abq.size() + "\n");
    }

    public static void main(String[] args) throws InterruptedException {
        System.out.println("=== Q6: Deadlock Prevention & Bounded Mess Token Counter ===\n");
        demonstrateDeadlockDetectionAndPrevention();
        traceBoundedCounterBounds();
    }
}
