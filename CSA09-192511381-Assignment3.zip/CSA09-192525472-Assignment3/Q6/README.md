# Q6 – Deadlock and Inter-Thread Communication

* `src/TokenCounter.java`: Completed `TODO 1` and `TODO 2` (`Sum of tokens collected: 210 (expected 210)`).
* `src/HostelDeadlockAndCounterDemo.java`: JVM `ThreadMXBean` deadlock detection on unsafe wallet transfers, global lock-ordering prevention, bounded buffer invariant verification (`0 <= count <= 5`), and `ArrayBlockingQueue(5)` comparison.

## Run
```sh
sh run.sh
```
