#!/bin/sh
cd "$(dirname "$0")"
mkdir -p out output
javac -d out src/*.java
java -cp out TokenCounter | tee output/TokenCounter_output.txt
java -cp out HostelDeadlockAndCounterDemo | tee output/HostelDeadlockAndCounterDemo_output.txt
