# Q7 – Design a Concurrent, Fault-Tolerant Processor from First Principles

* Implements a fault-tolerant 10,000-file semester result processor using `ExecutorService`, `Callable<FileTaskOutcome>`, `Future`, `ConcurrentHashMap`, and `AtomicInteger`, benchmarked across thread pools of sizes 1, 2, 4, and 8 alongside `parallelStream()`.

## Run
```sh
sh run.sh
```
