import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

public class SemesterResultProcessor {

    static class StudentResult {
        final String regNo;
        final double average;
        final String grade;

        StudentResult(String regNo, double average, String grade) {
            this.regNo = regNo;
            this.average = average;
            this.grade = grade;
        }

        @Override
        public String toString() {
            return String.format("%s -> Avg=%.2f (%s)", regNo, average, grade);
        }
    }

    static class FileTaskOutcome {
        final String filePath;
        final boolean success;
        final StudentResult result;
        final String errorReason;

        FileTaskOutcome(String filePath, StudentResult result) {
            this.filePath = filePath;
            this.success = true;
            this.result = result;
            this.errorReason = null;
        }

        FileTaskOutcome(String filePath, String errorReason) {
            this.filePath = filePath;
            this.success = false;
            this.result = null;
            this.errorReason = errorReason;
        }
    }

    static String computeGrade(double avg) {
        if (avg >= 90) return "S";
        if (avg >= 80) return "A";
        if (avg >= 70) return "B";
        if (avg >= 60) return "C";
        if (avg >= 50) return "D";
        return "F";
    }

    static StudentResult parseAndEvaluateFile(String filePath) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String regLine = br.readLine();
            String marksLine = br.readLine();
            if (regLine == null || marksLine == null || regLine.trim().isEmpty()) {
                throw new IllegalArgumentException("Truncated or empty score file");
            }
            String regNo = regLine.trim();
            String[] tokens = marksLine.split(",");
            if (tokens.length != 5) {
                throw new IllegalArgumentException("Expected 5 subject marks, found " + tokens.length);
            }
            double sum = 0;
            for (String tok : tokens) {
                double m = Double.parseDouble(tok.trim());
                if (m < 0 || m > 100) {
                    throw new IllegalArgumentException("Mark out of valid range [0..100]: " + m);
                }
                sum += m;
            }
            double avg = sum / 5.0;
            return new StudentResult(regNo, avg, computeGrade(avg));
        }
    }

    static class BatchSummary {
        final int totalFiles;
        final int succeeded;
        final int failed;
        final double elapsedMs;
        final Map<String, StudentResult> resultsMap;
        final List<String> failureLogs;

        BatchSummary(int totalFiles, int succeeded, int failed, double elapsedMs,
                     Map<String, StudentResult> resultsMap, List<String> failureLogs) {
            this.totalFiles = totalFiles;
            this.succeeded = succeeded;
            this.failed = failed;
            this.elapsedMs = elapsedMs;
            this.resultsMap = resultsMap;
            this.failureLogs = failureLogs;
        }
    }

    static BatchSummary processBatch(List<String> filePaths, int poolSize) throws InterruptedException {
        long t0 = System.nanoTime();
        ExecutorService executor = Executors.newFixedThreadPool(poolSize);
        ConcurrentHashMap<String, StudentResult> sharedResults = new ConcurrentHashMap<>();
        AtomicInteger successCounter = new AtomicInteger(0);
        AtomicInteger failureCounter = new AtomicInteger(0);

        List<Callable<FileTaskOutcome>> tasks = new ArrayList<>(filePaths.size());
        for (String path : filePaths) {
            tasks.add(() -> {
                try {
                    StudentResult res = parseAndEvaluateFile(path);
                    sharedResults.put(res.regNo, res);
                    successCounter.incrementAndGet();
                    return new FileTaskOutcome(path, res);
                } catch (FileNotFoundException fnf) {
                    failureCounter.incrementAndGet();
                    return new FileTaskOutcome(path, "Missing file: " + fnf.getMessage());
                } catch (IOException io) {
                    failureCounter.incrementAndGet();
                    return new FileTaskOutcome(path, "I/O error: " + io.getMessage());
                } catch (RuntimeException badData) {
                    failureCounter.incrementAndGet();
                    return new FileTaskOutcome(path, "Corrupt data (" + badData.getClass().getSimpleName() + "): " + badData.getMessage());
                }
            });
        }

        List<Future<FileTaskOutcome>> futures = executor.invokeAll(tasks);
        List<String> failureLogs = new ArrayList<>();
        for (Future<FileTaskOutcome> f : futures) {
            try {
                FileTaskOutcome outcome = f.get();
                if (!outcome.success) {
                    failureLogs.add(outcome.filePath + " -> " + outcome.errorReason);
                }
            } catch (ExecutionException ee) {
                failureCounter.incrementAndGet();
                failureLogs.add("Unexpected task execution error: " + ee.getCause());
            }
        }
        executor.shutdown();
        double elapsedMs = (System.nanoTime() - t0) / 1e6;
        return new BatchSummary(filePaths.size(), successCounter.get(), failureCounter.get(),
                elapsedMs, sharedResults, failureLogs);
    }

    static List<String> prepareDataset(String dirPath, int totalCount, int missingCount, int corruptCount) throws IOException {
        File dir = new File(dirPath);
        if (!dir.exists()) dir.mkdirs();
        List<String> paths = new ArrayList<>(totalCount);
        Random rng = new Random(192525472L);

        for (int i = 0; i < totalCount; i++) {
            String regNo = String.format("1925%05d", i + 1);
            String filePath = dirPath + "/score_" + regNo + ".txt";
            paths.add(filePath);

            if (i < missingCount) {
                File f = new File(filePath);
                if (f.exists()) f.delete();
                continue;
            }
            try (FileWriter fw = new FileWriter(filePath)) {
                fw.write(regNo + "\n");
                if (i < missingCount + corruptCount) {
                    fw.write("85,90,CORRUPT_MARK,78,88\n");
                } else {
                    int m1 = 55 + rng.nextInt(45);
                    int m2 = 55 + rng.nextInt(45);
                    int m3 = 55 + rng.nextInt(45);
                    int m4 = 55 + rng.nextInt(45);
                    int m5 = 55 + rng.nextInt(45);
                    fw.write(m1 + "," + m2 + "," + m3 + "," + m4 + "," + m5 + "\n");
                }
            }
        }
        return paths;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== Q7: Concurrent Fault-Tolerant Semester Result Processor ===\n");

        List<String> smallBatch = prepareDataset("input/handcheck_scores", 10, 1, 2);
        BatchSummary smallSummary = processBatch(smallBatch, 2);
        System.out.println("--- 1. Hand-Checked Verification Set (10 files: 7 valid, 1 missing, 2 corrupt) ---");
        System.out.printf("  Processed=%d | Succeeded=%d | Failed=%d | ConcurrentHashMap.size=%d%n",
                smallSummary.totalFiles, smallSummary.succeeded, smallSummary.failed, smallSummary.resultsMap.size());
        System.out.println("  Sample Computed Result: " + smallSummary.resultsMap.get("192500004"));
        System.out.println("  Sample Failure Log    : " + smallSummary.failureLogs.get(0) + "\n");

        List<String> fullBatch = prepareDataset("input/semester_10k", 10_000, 50, 100);
        System.out.println("--- 2. Full 10,000-File Benchmark Across Thread Pool Sizes (1, 2, 4, 8) ---");
        for (int threads : new int[]{1, 2, 4, 8}) {
            BatchSummary s = processBatch(fullBatch, threads);
            System.out.printf("  Pool Size = %d -> Time: %7.2f ms | Total: %d | Success: %d | Failed: %d | MapSize: %d%n",
                    threads, s.elapsedMs, s.totalFiles, s.succeeded, s.failed, s.resultsMap.size());
        }

        long t0 = System.nanoTime();
        ConcurrentHashMap<String, StudentResult> streamMap = new ConcurrentHashMap<>();
        AtomicInteger streamFail = new AtomicInteger(0);
        fullBatch.parallelStream().forEach(path -> {
            try {
                StudentResult r = parseAndEvaluateFile(path);
                streamMap.put(r.regNo, r);
            } catch (Exception e) {
                streamFail.incrementAndGet();
            }
        });
        double streamMs = (System.nanoTime() - t0) / 1e6;
        System.out.printf("%n--- 3. Alternative Concept: parallelStream() on 10,000 Files ---%n");
        System.out.printf("  parallelStream() -> Time: %7.2f ms | Success: %d | Failed: %d%n",
                streamMs, streamMap.size(), streamFail.get());
    }
}
